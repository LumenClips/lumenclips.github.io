@echo off
cd /d "%~dp0"
if not exist Lumen.exe (
  echo Setting up Lumen for the first time, one moment...
  "%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe" /nologo /target:winexe /platform:x64 /optimize+ /out:Lumen.exe /r:System.Windows.Forms.dll /r:System.Drawing.dll /r:System.IO.Compression.dll /r:System.IO.Compression.FileSystem.dll /r:Microsoft.VisualBasic.dll Lumen.cs > setup-log.txt
  if errorlevel 1 (
    type setup-log.txt
    echo.
    echo Setup failed. Send setup-log.txt to Claude.
    pause
    exit /b 1
  )
)
start "" Lumen.exe
