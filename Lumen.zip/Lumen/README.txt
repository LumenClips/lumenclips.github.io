LUMEN - save the last 30 seconds of your game with one key

START
1. Extract this zip.
2. Double-click "Open Lumen.bat". The first time it builds Lumen.exe (a few seconds).
3. Lumen asks to download ffmpeg once (free video tool, about 90 MB).

USE
- Press F9 in any game. The last 30 seconds are saved as a clip.
- Click a clip to play it right in Lumen (Space pause, arrows skip, Esc back). Click Share to copy it, then paste it in Discord.
  Clips over 10 MB are shrunk first so Discord accepts them.
- Right-click a clip for: Copy file, Show in folder, Delete.
- Closing the window keeps Lumen recording in the tray. Quit from the tray icon.

NOTES
- Clips are saved in Videos\Lumen (change it in Settings).
- Records with your graphics card (NVIDIA or AMD), so games barely slow down.
- If you replace Lumen.cs with a newer one, delete Lumen.exe first.
- Lumen counts users anonymously (random id + version). Turn it off in Settings.
- Your mic is recorded too. Right-click a clip (or use the player) to turn the mic off/on or rename.
