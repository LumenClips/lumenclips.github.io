﻿// Lumen - keeps the last seconds of your screen, saves a clip on one key.
// Build: double-click "Open Lumen.bat" (uses the C# compiler built into Windows).
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

static class Program {
    [DllImport("user32.dll")] static extern bool SetProcessDPIAware();
    [STAThread]
    static void Main(string[] args) {
        bool fresh;
        var mutex = new Mutex(true, "Lumen.SingleInstance", out fresh);
        if (!fresh) {
            try { EventWaitHandle.OpenExisting("Lumen.Show").Set(); } catch { }
            return;
        }
        try { SetProcessDPIAware(); } catch { }
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        using (var g = Graphics.FromHwnd(IntPtr.Zero)) T.S = g.DpiX / 96f;
        Cfg.Load();
        Application.Run(new MainForm(args.Contains("/tray")));
        GC.KeepAlive(mutex);
    }
}

// ---------- settings ----------
static class Cfg {
    public static readonly string Roaming = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Lumen");
    public static readonly string Local = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Lumen");
    public static readonly CultureInfo CI = CultureInfo.InvariantCulture;
    static Dictionary<string, string> d = new Dictionary<string, string>();
    static string FilePath { get { return Path.Combine(Roaming, "settings.txt"); } }
    public static void Load() {
        try {
            foreach (var l in File.ReadAllLines(FilePath)) {
                int i = l.IndexOf('=');
                if (i > 0) d[l.Substring(0, i)] = l.Substring(i + 1);
            }
        } catch { }
    }
    public static string Get(string k, string def) { string v; return d.TryGetValue(k, out v) && v != "" ? v : def; }
    public static int GetI(string k, int def) { int r; return int.TryParse(Get(k, ""), out r) ? r : def; }
    public static void Set(string k, object v) {
        d[k] = Convert.ToString(v, CI);
        try { Directory.CreateDirectory(Roaming); File.WriteAllLines(FilePath, d.Select(p => p.Key + "=" + p.Value).ToArray()); } catch { }
    }
    public static int Length { get { return GetI("length", 30); } }
    public static int Fps { get { return GetI("fps", 60); } }
    public static string Quality { get { return Get("quality", "Normal"); } }
    public static string Key { get { return Get("key", "F9"); } }
    public static int Screen { get { return GetI("screen", 0); } }
    public static string ClipDir {
        get {
            string p = Get("folder", Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyVideos), "Lumen"));
            try { Directory.CreateDirectory(p); } catch { }
            return p;
        }
    }
    public static string FFmpeg {
        get {
            string a = Path.Combine(Application.StartupPath, "ffmpeg.exe");
            if (File.Exists(a)) return a;
            string b = Path.Combine(Local, "ffmpeg", "ffmpeg.exe");
            return File.Exists(b) ? b : null;
        }
    }
    public static string LenText(int s) { return s < 60 ? s + " seconds" : s == 60 ? "1 minute" : (s / 60) + " minutes"; }
}

// ---------- look ----------
static class T {
    public static float S = 1;
    public static int D(float v) { return (int)Math.Round(v * S); }
    public static readonly Color Table = C("EEF1F5"), Ink = C("1E2230"), Ink2 = C("343B52"), Mute = C("6A7184"),
        Line = C("D6DBE4"), Lamp = C("FFB300"), Stop = C("D64545"), Soft = C("B9C0D0");
    static Color C(string h) { return ColorTranslator.FromHtml("#" + h); }
    static string disp; static bool dispBold;
    static Dictionary<string, Font> cache = new Dictionary<string, Font>();
    public static Font Display(float pt) {
        if (disp == null) {
            disp = "Segoe UI Semibold";
            using (var fc = new InstalledFontCollection()) {
                var names = fc.Families.Select(f => f.Name).ToList();
                if (names.Contains("Bahnschrift SemiBold")) disp = "Bahnschrift SemiBold";
                else if (names.Contains("Bahnschrift")) { disp = "Bahnschrift"; dispBold = true; }
            }
        }
        return Get(disp, pt, dispBold ? FontStyle.Bold : FontStyle.Regular);
    }
    public static Font Body(float pt, bool bold) { return Get(bold ? "Segoe UI Semibold" : "Segoe UI", pt, FontStyle.Regular); }
    static Font Get(string n, float pt, FontStyle st) {
        string k = n + pt + st; Font f;
        if (!cache.TryGetValue(k, out f)) { f = new Font(n, pt, st); cache[k] = f; }
        return f;
    }
    public static GraphicsPath Round(RectangleF r, float rad) {
        var p = new GraphicsPath(); float d = rad * 2;
        if (d <= 0) { p.AddRectangle(r); return p; }
        p.AddArc(r.X, r.Y, d, d, 180, 90); p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
        p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90); p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
        p.CloseFigure(); return p;
    }
    public static void Hq(Graphics g) {
        g.SmoothingMode = SmoothingMode.AntiAlias; g.InterpolationMode = InterpolationMode.HighQualityBicubic;
        g.PixelOffsetMode = PixelOffsetMode.HighQuality; g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
    }
    public static void Text(Graphics g, string s, Font f, Color c, Rectangle r, TextFormatFlags fl) {
        if ((fl & TextFormatFlags.WordBreak) == 0) fl |= TextFormatFlags.SingleLine;
        TextRenderer.DrawText(g, s, f, r, c, fl | TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix | TextFormatFlags.PreserveGraphicsTranslateTransform | TextFormatFlags.PreserveGraphicsClipping);
    }
    public static Icon MakeIcon(int size) {
        var b = new Bitmap(size, size);
        using (var g = Graphics.FromImage(b)) {
            Hq(g); g.Clear(Color.Transparent);
            using (var br = new SolidBrush(Ink)) g.FillEllipse(br, 0, 0, size - 1, size - 1);
            float c = size * 0.26f;
            using (var br = new SolidBrush(Lamp)) g.FillEllipse(br, c, c, size - 1 - 2 * c, size - 1 - 2 * c);
        }
        return Icon.FromHandle(b.GetHicon());
    }
}

class Canvas : Panel {
    public Canvas() {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
    }
}

class Btn : Control {
    public bool Primary; public string Hint; bool hot, down; float h, pr; DateTime last;
    System.Windows.Forms.Timer tm;
    public Btn(string text, bool primary) {
        Text = text; Primary = primary; Cursor = Cursors.Hand; TabStop = true;
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.Selectable | ControlStyles.ResizeRedraw, true);
        Font = T.Body(10, true); Height = T.D(38); Fit();
        tm = new System.Windows.Forms.Timer { Interval = 15 };
        tm.Tick += (s, e) => {
            float dt = (float)(DateTime.Now - last).TotalSeconds; last = DateTime.Now;
            h = Anim.To(h, hot ? 1 : 0, dt, 16); pr = Anim.To(pr, down ? 1 : 0, dt, 30);
            if (h == (hot ? 1 : 0) && pr == (down ? 1 : 0)) tm.Stop();
            Invalidate();
        };
    }
    void Kick() { if (!tm.Enabled) { last = DateTime.Now; tm.Start(); } }
    protected override void Dispose(bool d) { if (d) tm.Dispose(); base.Dispose(d); }
    public void Fit() {
        int w = TextRenderer.MeasureText(Text, Font).Width + T.D(32);
        if (Hint != null) w += TextRenderer.MeasureText(Hint, Font).Width + T.D(10);
        Width = w;
    }
    protected override void OnMouseEnter(EventArgs e) { hot = true; Kick(); base.OnMouseEnter(e); }
    protected override void OnMouseLeave(EventArgs e) { hot = false; down = false; Kick(); base.OnMouseLeave(e); }
    protected override void OnMouseDown(MouseEventArgs e) { down = true; Kick(); base.OnMouseDown(e); }
    protected override void OnMouseUp(MouseEventArgs e) { down = false; Kick(); base.OnMouseUp(e); }
    protected override void OnGotFocus(EventArgs e) { Invalidate(); base.OnGotFocus(e); }
    protected override void OnLostFocus(EventArgs e) { Invalidate(); base.OnLostFocus(e); }
    protected override void OnKeyDown(KeyEventArgs e) {
        if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Space) OnClick(EventArgs.Empty);
        base.OnKeyDown(e);
    }
    protected override void OnPaint(PaintEventArgs e) {
        var g = e.Graphics; T.Hq(g); g.Clear(Parent != null ? Parent.BackColor : T.Table);
        float k = 0.035f * pr;
        var r = new RectangleF(1 + Width * k / 2, 1 + Height * k / 2, (Width - 3) * (1 - k), (Height - 3) * (1 - k));
        Color pb = Parent != null ? Parent.BackColor : T.Table;
        using (var p = T.Round(r, T.D(8))) {
            Color bg = Primary ? Gallery.Blend(T.Ink, T.Ink2, h) : Gallery.Blend(pb, Color.White, h);
            using (var b = new SolidBrush(bg)) g.FillPath(b, p);
            if (!Primary) using (var pen = new Pen(Gallery.Blend(T.Line, T.Soft, h))) g.DrawPath(pen, p);
            if (Primary && h > 0.01f) using (var pen = new Pen(Color.FromArgb((int)(140 * h), T.Lamp), T.D(1))) g.DrawPath(pen, p);
            if (Focused) using (var pen = new Pen(T.Lamp, T.D(2))) g.DrawPath(pen, p);
        }
        Color fg = Primary ? Color.White : T.Ink;
        int tw = TextRenderer.MeasureText(Text, Font).Width;
        int hw = Hint != null ? TextRenderer.MeasureText(Hint, Font).Width + T.D(10) : 0;
        int x = (Width - tw - hw) / 2;
        T.Text(g, Text, Font, fg, new Rectangle(x, 0, tw + 2, Height), TextFormatFlags.VerticalCenter);
        if (Hint != null) T.Text(g, Hint, Font, Primary ? T.Lamp : T.Mute, new Rectangle(x + tw + T.D(10), 0, hw, Height), TextFormatFlags.VerticalCenter);
    }
}

// ---------- system audio (WASAPI loopback) ----------
[ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")] class MMDeviceEnumeratorCo { }
[ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IMMDeviceEnumerator {
    [PreserveSig] int EnumAudioEndpoints(int flow, int mask, out IntPtr devices);
    [PreserveSig] int GetDefaultAudioEndpoint(int flow, int role, out IMMDevice dev);
}
[ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IMMDevice {
    [PreserveSig] int Activate(ref Guid iid, int ctx, IntPtr p, [MarshalAs(UnmanagedType.IUnknown)] out object o);
}
[ComImport, Guid("1CB9AD4C-DBFA-4c32-B178-C2F568A703B2"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IAudioClient {
    [PreserveSig] int Initialize(int share, int flags, long dur, long period, IntPtr fmt, IntPtr session);
    [PreserveSig] int GetBufferSize(out uint frames);
    [PreserveSig] int GetStreamLatency(out long lat);
    [PreserveSig] int GetCurrentPadding(out uint pad);
    [PreserveSig] int IsFormatSupported(int share, IntPtr fmt, out IntPtr closest);
    [PreserveSig] int GetMixFormat(out IntPtr fmt);
    [PreserveSig] int GetDevicePeriod(out long def, out long min);
    [PreserveSig] int Start();
    [PreserveSig] int Stop();
    [PreserveSig] int Reset();
    [PreserveSig] int SetEventHandle(IntPtr h);
    [PreserveSig] int GetService(ref Guid iid, [MarshalAs(UnmanagedType.IUnknown)] out object o);
}
[ComImport, Guid("C8ADBD64-E71E-48a0-A4DE-185C395CD317"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IAudioCaptureClient {
    [PreserveSig] int GetBuffer(out IntPtr data, out uint frames, out uint flags, out ulong devPos, out ulong qpcPos);
    [PreserveSig] int ReleaseBuffer(uint frames);
    [PreserveSig] int GetNextPacketSize(out uint frames);
}

class LoopAudio {
    public volatile bool Ok; readonly bool mic;
    public LoopAudio(bool mic) { this.mic = mic; }
    int rate = 48000; short[] ring = new short[2]; long total; long cap = 1;
    DateTime t0; double q0; Stopwatch sw = new Stopwatch();
    readonly object lk = new object(); volatile bool run;
    const int Seconds = 150;

    public void Start() {
        if (run) return;
        run = true;
        var th = new Thread(() => {
            while (run) {
                try { Capture(); } catch { Ok = false; }
                if (run) Thread.Sleep(1500);
            }
        });
        th.IsBackground = true; th.Start();
    }
    public void Stop() { run = false; }

    static short S16(float v) { if (v > 1) v = 1; if (v < -1) v = -1; return (short)(v * 32767); }

    void Capture() {
        var en = (IMMDeviceEnumerator)new MMDeviceEnumeratorCo();
        IMMDevice dev; Marshal.ThrowExceptionForHR(en.GetDefaultAudioEndpoint(mic ? 1 : 0, 0, out dev));
        Guid iid = typeof(IAudioClient).GUID; object o;
        Marshal.ThrowExceptionForHR(dev.Activate(ref iid, 23, IntPtr.Zero, out o));
        var ac = (IAudioClient)o;
        IntPtr fmt; Marshal.ThrowExceptionForHR(ac.GetMixFormat(out fmt));
        int tag = (ushort)Marshal.ReadInt16(fmt, 0), ch = Marshal.ReadInt16(fmt, 2), r = Marshal.ReadInt32(fmt, 4), bits = Marshal.ReadInt16(fmt, 14);
        bool isFloat = tag == 3;
        if (tag == 0xFFFE) {
            var sub = (Guid)Marshal.PtrToStructure(new IntPtr(fmt.ToInt64() + 24), typeof(Guid));
            isFloat = sub == new Guid("00000003-0000-0010-8000-00aa00389b71");
        }
        Marshal.ThrowExceptionForHR(ac.Initialize(0, mic ? 0 : 0x00020000, 10000000, 0, fmt, IntPtr.Zero));
        Guid ciid = typeof(IAudioCaptureClient).GUID; object co;
        Marshal.ThrowExceptionForHR(ac.GetService(ref ciid, out co));
        var cc = (IAudioCaptureClient)co;
        lock (lk) {
            rate = r; cap = (long)r * Seconds; ring = new short[cap * 2]; total = 0;
            t0 = DateTime.Now; sw.Restart(); q0 = Stopwatch.GetTimestamp() * 1e7 / Stopwatch.Frequency;
        }
        Marshal.ThrowExceptionForHR(ac.Start());
        Ok = true;
        var tmp = new short[0]; float[] fb = new float[0]; short[] sb = new short[0];
        long lastData = 0;
        try {
            while (run) {
                uint n; Marshal.ThrowExceptionForHR(cc.GetNextPacketSize(out n));
                while (n > 0) {
                    IntPtr data; uint frames, flags; ulong dp, qp;
                    Marshal.ThrowExceptionForHR(cc.GetBuffer(out data, out frames, out flags, out dp, out qp));
                    int f = (int)frames;
                    if (tmp.Length < f * 2) tmp = new short[f * 2];
                    if ((flags & 2) != 0 || (!isFloat && bits != 16)) Array.Clear(tmp, 0, f * 2);
                    else if (isFloat) {
                        if (fb.Length < f * ch) fb = new float[f * ch];
                        Marshal.Copy(data, fb, 0, f * ch);
                        for (int i = 0; i < f; i++) { tmp[i * 2] = S16(fb[i * ch]); tmp[i * 2 + 1] = S16(ch > 1 ? fb[i * ch + 1] : fb[i * ch]); }
                    } else {
                        if (sb.Length < f * ch) sb = new short[f * ch];
                        Marshal.Copy(data, sb, 0, f * ch);
                        for (int i = 0; i < f; i++) { tmp[i * 2] = sb[i * ch]; tmp[i * 2 + 1] = ch > 1 ? sb[i * ch + 1] : sb[i * ch]; }
                    }
                    cc.ReleaseBuffer(frames);
                    long target = (long)((qp - q0) / 1e7 * rate);
                    lock (lk) {
                        if (target > total + rate / 50) Silence(target - total);
                        Write(tmp, f);
                    }
                    lastData = sw.ElapsedMilliseconds;
                    Marshal.ThrowExceptionForHR(cc.GetNextPacketSize(out n));
                }
                if (sw.ElapsedMilliseconds - lastData > 100) {
                    long now = (long)(sw.Elapsed.TotalSeconds * rate) - rate / 50;
                    lock (lk) { if (now > total) Silence(now - total); }
                }
                Thread.Sleep(10);
            }
        } finally {
            Ok = false;
            try { ac.Stop(); } catch { }
            Marshal.FreeCoTaskMem(fmt);
        }
    }
    void Silence(long frames) {
        frames = Math.Min(frames, cap);
        for (long i = 0; i < frames; i++) { long k = (total % cap) * 2; ring[k] = 0; ring[k + 1] = 0; total++; }
    }
    void Write(short[] src, int frames) {
        for (int i = 0; i < frames; i++) { long k = (total % cap) * 2; ring[k] = src[i * 2]; ring[k + 1] = src[i * 2 + 1]; total++; }
    }

    // Writes the audio between two clock times as a 16-bit stereo WAV.
    public bool WriteWav(string path, DateTime a, DateTime b) {
        if (!Ok) return false;
        short[] buf; int r;
        lock (lk) {
            r = rate;
            long fa = (long)((a - t0).TotalSeconds * rate), fb = (long)((b - t0).TotalSeconds * rate);
            long n = fb - fa; if (n <= 0 || n > cap) return false;
            buf = new short[n * 2];
            for (long i = 0; i < n; i++) {
                long idx = fa + i;
                if (idx >= 0 && idx < total && idx >= total - cap) { long k = (idx % cap) * 2; buf[i * 2] = ring[k]; buf[i * 2 + 1] = ring[k + 1]; }
            }
        }
        using (var w = new BinaryWriter(File.Create(path))) {
            int bytes = buf.Length * 2;
            w.Write(Encoding.ASCII.GetBytes("RIFF")); w.Write(36 + bytes); w.Write(Encoding.ASCII.GetBytes("WAVEfmt "));
            w.Write(16); w.Write((short)1); w.Write((short)2); w.Write(r); w.Write(r * 4); w.Write((short)4); w.Write((short)16);
            w.Write(Encoding.ASCII.GetBytes("data")); w.Write(bytes);
            var raw = new byte[bytes]; Buffer.BlockCopy(buf, 0, raw, 0, bytes); w.Write(raw);
        }
        return true;
    }
}

// ---------- screen recorder (ffmpeg, rolling 2 s pieces) ----------
class Seg { public string File; public double S, E; }

class Recorder {
    public readonly string BufDir = Path.Combine(Cfg.Local, "buffer");
    public string Encoder; public volatile string LastError = "";
    public event Action<bool, string> Changed;
    Process p; volatile bool stopping; int fails;
    DateTime epoch; double offset; bool haveOff; int parsed;
    readonly List<Seg> segs = new List<Seg>(); readonly object lk = new object();

    public bool Running { get { var q = p; return q != null && !q.HasExited; } }

    public static string VideoArgs(string enc, int fps, int screen, string quality) {
        string src = "-f lavfi -i ddagrab=output_idx=" + screen + ":framerate=" + fps;
        int cq = quality == "High" ? 19 : quality == "Small" ? 28 : 23;
        int mb = quality == "High" ? 40 : quality == "Small" ? 10 : 20;
        string gop = " -g " + fps + " -bf 0";
        if (enc == "h264_nvenc") return src + " -c:v h264_nvenc -preset p4 -rc vbr -cq " + cq + " -b:v 0 -maxrate " + (mb * 2) + "M -bufsize " + (mb * 2) + "M" + gop;
        if (enc == "h264_amf") return src + " -c:v h264_amf -quality balanced -rc vbr_peak -b:v " + mb + "M -maxrate " + (mb * 3 / 2) + "M" + gop;
        return src + " -vf hwdownload,format=bgra -c:v libx264 -preset ultrafast -crf " + (cq + 2) + " -pix_fmt yuv420p" + gop;
    }

    public static int Run(string args, int ms, StringBuilder err) {
        try {
            var psi = new ProcessStartInfo(Cfg.FFmpeg, args);
            psi.UseShellExecute = false; psi.CreateNoWindow = true; psi.RedirectStandardError = true; psi.RedirectStandardOutput = true;
            using (var pr = new Process()) {
                pr.StartInfo = psi;
                pr.ErrorDataReceived += (s, e) => { if (e.Data != null && err != null) lock (err) err.AppendLine(e.Data); };
                pr.OutputDataReceived += (s, e) => { };
                pr.Start(); pr.BeginErrorReadLine(); pr.BeginOutputReadLine();
                if (!pr.WaitForExit(ms)) { try { pr.Kill(); } catch { } return -1; }
                pr.WaitForExit();
                return pr.ExitCode;
            }
        } catch (Exception ex) { if (err != null) err.AppendLine(ex.Message); return -1; }
    }

    // Finds a video encoder that works on this PC (graphics card first).
    public static string Probe() {
        foreach (var enc in new[] { "h264_nvenc", "h264_amf", "libx264" }) {
            string a = "-hide_banner -loglevel error -y " + VideoArgs(enc, 30, Cfg.Screen, "Normal") + " -t 1 -f null -";
            if (Run(a, 20000, null) == 0) return enc;
        }
        return null;
    }

    public static void KillStale() {
        string ff = Cfg.FFmpeg; if (ff == null) return;
        foreach (var pr in Process.GetProcessesByName("ffmpeg")) {
            try { if (string.Equals(pr.MainModule.FileName, ff, StringComparison.OrdinalIgnoreCase)) pr.Kill(); } catch { }
        }
    }

    public void Start() {
        Stop();
        stopping = false;
        try { if (Directory.Exists(BufDir)) Directory.Delete(BufDir, true); } catch { }
        Directory.CreateDirectory(BufDir);
        lock (lk) { segs.Clear(); parsed = 0; haveOff = false; offset = 0; }
        int wrap = Cfg.Length / 2 + 6;
        string args = "-hide_banner -loglevel error -y " + VideoArgs(Encoder, Cfg.Fps, Cfg.Screen, Cfg.Quality) +
            " -f segment -segment_time 2 -segment_format mpegts -reset_timestamps 1 -segment_wrap " + wrap +
            " -segment_list \"" + Path.Combine(BufDir, "list.csv") + "\" -segment_list_type csv \"" + Path.Combine(BufDir, "s%03d.ts") + "\"";
        var psi = new ProcessStartInfo(Cfg.FFmpeg, args);
        psi.UseShellExecute = false; psi.CreateNoWindow = true; psi.RedirectStandardInput = true; psi.RedirectStandardError = true;
        var me = new Process(); me.StartInfo = psi; me.EnableRaisingEvents = true;
        me.ErrorDataReceived += (s, e) => { if (!string.IsNullOrEmpty(e.Data)) LastError = e.Data; };
        me.Exited += (s, e) => {
            if (stopping || p != me) return;
            fails++;
            if (Changed != null) Changed(false, LastError);
            if (fails <= 3) ThreadPool.QueueUserWorkItem(_ => { Thread.Sleep(3000); if (!stopping && p == me) Start(); });
        };
        LastError = "";
        epoch = DateTime.Now;
        try { me.Start(); } catch (Exception ex) { LastError = ex.Message; if (Changed != null) Changed(false, LastError); return; }
        p = me;
        me.BeginErrorReadLine();
        var th = new Thread(() => Poll(me)); th.IsBackground = true; th.Start();
        if (Changed != null) Changed(true, "");
    }

    public void Stop() {
        stopping = true;
        var q = p; p = null;
        if (q == null) return;
        try {
            if (!q.HasExited) {
                try { q.StandardInput.Write('q'); q.StandardInput.Flush(); } catch { }
                if (!q.WaitForExit(3000)) q.Kill();
            }
        } catch { }
    }

    void Poll(Process me) {
        string csv = Path.Combine(BufDir, "list.csv"); long lastLen = -1; var started = DateTime.Now;
        while (!stopping && p == me) {
            try {
                if ((DateTime.Now - started).TotalSeconds > 60) fails = 0;
                if (File.Exists(csv)) {
                    long len = new FileInfo(csv).Length;
                    if (len != lastLen) {
                        lastLen = len; string txt;
                        using (var fs = new FileStream(csv, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                        using (var sr = new StreamReader(fs)) txt = sr.ReadToEnd();
                        var lines = txt.Split('\n');
                        double now = (DateTime.Now - epoch).TotalSeconds;
                        lock (lk) {
                            for (int i = parsed; i < lines.Length - 1; i++) {
                                var c = lines[i].Trim().Split(',');
                                double s, e;
                                if (c.Length < 3 || !double.TryParse(c[1], NumberStyles.Float, Cfg.CI, out s) || !double.TryParse(c[2], NumberStyles.Float, Cfg.CI, out e)) continue;
                                segs.Add(new Seg { File = c[0].Trim('"'), S = s, E = e });
                                double off = now - e;
                                if (!haveOff || off < offset) { offset = off; haveOff = true; }
                            }
                            parsed = Math.Max(parsed, lines.Length - 1);
                            if (segs.Count > 300) segs.RemoveRange(0, segs.Count - 300);
                        }
                    }
                }
            } catch { }
            Thread.Sleep(100);
        }
    }

    public List<Seg> Snapshot() { lock (lk) return segs.ToList(); }
    public DateTime Wall(double t) { lock (lk) return epoch.AddSeconds(t + offset); }
}

// ---------- saving and sharing clips ----------
static class Clipper {
    [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder sb, int max);
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);

    public static string GameTitle() {
        try {
            var h = GetForegroundWindow(); uint pid; GetWindowThreadProcessId(h, out pid);
            if (pid == (uint)Process.GetCurrentProcess().Id) return "Clip";
            var sb = new StringBuilder(256); GetWindowText(h, sb, 256);
            string t = sb.ToString();
            if (t == "" || t == "Program Manager") t = "Desktop";
            foreach (var c in Path.GetInvalidFileNameChars()) t = t.Replace(c.ToString(), "");
            t = t.Trim(); if (t.Length > 40) t = t.Substring(0, 40).Trim();
            return t == "" ? "Clip" : t;
        } catch { return "Clip"; }
    }

    public static string Save(Recorder rec, LoopAudio au, LoopAudio mic, DateTime t, string title, out string err) {
        err = null;
        int len = Cfg.Length;
        var wait = Stopwatch.StartNew(); List<Seg> all = null;
        while (wait.ElapsedMilliseconds < 6000) {
            all = rec.Snapshot();
            if (all.Count > 0 && rec.Wall(all[all.Count - 1].E) >= t.AddSeconds(-0.2)) break;
            Thread.Sleep(100);
        }
        var pick = all == null ? new List<Seg>() : all.Where(s => rec.Wall(s.E) > t.AddSeconds(-len)).ToList();
        if (pick.Count > len / 2 + 2) pick = pick.Skip(pick.Count - (len / 2 + 2)).ToList();
        if (pick.Count == 0) { err = "Nothing recorded yet. Wait a few seconds and try again."; return null; }

        string work = Path.Combine(Cfg.Local, "work");
        try { if (Directory.Exists(work)) Directory.Delete(work, true); } catch { }
        Directory.CreateDirectory(work);
        var list = new StringBuilder();
        for (int i = 0; i < pick.Count; i++) {
            File.Copy(Path.Combine(rec.BufDir, pick[i].File), Path.Combine(work, "c" + i + ".ts"), true);
            list.Append("file 'c" + i + ".ts'\n");
        }
        File.WriteAllText(Path.Combine(work, "list.txt"), list.ToString());
        string wav = Path.Combine(work, "a.wav");
        bool hasAudio = false;
        try { hasAudio = au.WriteWav(wav, rec.Wall(pick[0].S), rec.Wall(pick[pick.Count - 1].E)); } catch { }
        string mwav = Path.Combine(work, "m.wav"); bool hasMic = false;
        if (Cfg.Get("mic", "1") == "1") try { hasMic = mic.WriteWav(mwav, rec.Wall(pick[0].S), rec.Wall(pick[pick.Count - 1].E)); } catch { }
        string aac = "-c:a aac -b:a 160k -shortest ", au1;
        if (hasAudio && hasMic)
            au1 = "-i \"" + wav + "\" -i \"" + mwav + "\" -filter_complex \"[1:a][2:a]amix=inputs=2:duration=first:normalize=0[mix]\" -map 0:v:0 -map \"[mix]\" -map 1:a:0 " + aac +
                  "-metadata:s:a:0 title=\"Game + mic\" -metadata:s:a:1 title=\"Game only\" -disposition:a:0 default -disposition:a:1 0 ";
        else if (hasAudio || hasMic) au1 = "-i \"" + (hasAudio ? wav : mwav) + "\" -map 0:v:0 -map 1:a:0 " + aac;
        else au1 = "";

        string outFile = Path.Combine(Cfg.ClipDir, title + " " + t.ToString("yyyy-MM-dd HH.mm.ss", Cfg.CI) + ".mp4");
        string args = "-hide_banner -loglevel error -y -f concat -safe 0 -i \"" + Path.Combine(work, "list.txt") + "\" " +
            au1 +
            "-c:v copy -movflags +faststart \"" + outFile + "\"";
        var sb = new StringBuilder();
        if (Recorder.Run(args, 60000, sb) != 0 || !File.Exists(outFile)) {
            err = "The clip could not be saved. " + sb.ToString().Trim().Split('\n').LastOrDefault();
            return null;
        }
        double dur = pick[pick.Count - 1].E - pick[0].S;
        Thumbs.Make(outFile, dur);
        try { Directory.Delete(work, true); } catch { }
        return outFile;
    }

    static void Recycle(string p) {
        Microsoft.VisualBasic.FileIO.FileSystem.DeleteFile(p, Microsoft.VisualBasic.FileIO.UIOption.OnlyErrorDialogs, Microsoft.VisualBasic.FileIO.RecycleOption.SendToRecycleBin);
    }
    // Swaps which sound plays first: "Game + mic" or "Game only". Both tracks stay, so it can always be switched back.
    public static bool SwapMic(Clip c, out string err) {
        err = null;
        string dir = Path.Combine(Cfg.Local, "work"); Directory.CreateDirectory(dir);
        string tmp = Path.Combine(dir, "swap.mp4"); try { File.Delete(tmp); } catch { }
        var sb = new StringBuilder();
        if (Recorder.Run("-hide_banner -loglevel error -y -i \"" + c.Path + "\" -map 0:v:0 -map 0:a:1 -map 0:a:0 -c copy -disposition:a:0 default -disposition:a:1 0 -movflags +faststart \"" + tmp + "\"", 60000, sb) != 0 || !File.Exists(tmp)) {
            err = "This clip has no separate mic track."; return false;
        }
        var when = File.GetLastWriteTime(c.Path);
        string oldKey = Thumbs.Key(c.Path);
        File.Delete(c.Path); File.Move(tmp, c.Path); File.SetLastWriteTime(c.Path, when);
        foreach (var ext in new[] { ".jpg", ".txt" }) try { File.Delete(oldKey + ext); } catch { }
        Thumbs.Make(c.Path, c.Dur);
        return true;
    }
    static readonly Regex Stamp = new Regex(@" (\d{4}-\d{2}-\d{2} \d{2}\.\d{2}\.\d{2})$");
    public static string Rename(Clip c, string title) {
        foreach (var ch in Path.GetInvalidFileNameChars()) title = title.Replace(ch.ToString(), "");
        title = title.Trim(); if (title == "") return c.Path;
        var m = Stamp.Match(Path.GetFileNameWithoutExtension(c.Path));
        string stamp = m.Success ? m.Groups[1].Value : c.When.ToString("yyyy-MM-dd HH.mm.ss", Cfg.CI);
        string np = Path.Combine(Path.GetDirectoryName(c.Path), title + " " + stamp + ".mp4");
        if (string.Equals(np, c.Path, StringComparison.OrdinalIgnoreCase)) { if (np != c.Path) File.Move(c.Path, np); return np; }
        if (File.Exists(np)) throw new Exception("A clip with that name already exists.");
        string ok = Thumbs.Key(c.Path); File.Move(c.Path, np); string nk = Thumbs.Key(np);
        foreach (var ext in new[] { ".jpg", ".txt" }) try { if (File.Exists(ok + ext)) File.Move(ok + ext, nk + ext); } catch { }
        return np;
    }

    // Makes a copy small enough for Discord (under 10 MB) if needed. Returns the file to share.
    public static string ShareFile(string clip, double dur, string enc, out string err) {
        err = null;
        var fi = new FileInfo(clip);
        if (fi.Length <= 9500000) return clip;
        if (dur <= 0) dur = 30;
        string dir = Path.Combine(Cfg.Local, "share"); Directory.CreateDirectory(dir);
        string outFile = Path.Combine(dir, Path.GetFileNameWithoutExtension(clip) + ".mp4");
        if (File.Exists(outFile) && new FileInfo(outFile).LastWriteTime > fi.LastWriteTime) return outFile;
        int kb = (int)(8.6 * 8192 / dur) - 96;
        string scale = kb < 900 ? "480" : "720";
        if (kb < 150) kb = 150;
        string v = enc == "h264_nvenc" ? "-c:v h264_nvenc -preset p5 -b:v {0}k -maxrate {0}k -bufsize {1}k"
                 : enc == "h264_amf" ? "-c:v h264_amf -rc cbr -b:v {0}k -maxrate {0}k"
                 : "-c:v libx264 -preset veryfast -b:v {0}k -maxrate {0}k -bufsize {1}k -pix_fmt yuv420p";
        v = string.Format(v, kb, kb * 2);
        string args = "-hide_banner -loglevel error -y -i \"" + clip + "\" -vf scale=-2:" + scale + " " + v + " -c:a aac -b:a 96k -movflags +faststart \"" + outFile + "\"";
        var sb = new StringBuilder();
        if (Recorder.Run(args, 300000, sb) != 0 || !File.Exists(outFile)) { err = "Could not make a smaller copy."; return null; }
        return outFile;
    }
}

static class Thumbs {
    public static readonly string Dir = Path.Combine(Cfg.Local, "thumbs");
    public static string Key(string clip) {
        long len = 0; try { len = new FileInfo(clip).Length; } catch { }
        return Path.Combine(Dir, Path.GetFileNameWithoutExtension(clip) + "_" + len);
    }
    public static void Make(string clip, double dur) {
        Directory.CreateDirectory(Dir);
        string k = Key(clip); var sb = new StringBuilder();
        double at = dur > 1 ? dur * 0.5 : 1;
        Recorder.Run("-hide_banner -y -ss " + at.ToString("0.0", Cfg.CI) + " -i \"" + clip + "\" -frames:v 1 -vf scale=480:-2 -q:v 4 \"" + k + ".jpg\"", 30000, sb);
        if (dur <= 0) {
            var m = Regex.Match(sb.ToString(), @"Duration: (\d+):(\d+):(\d+(\.\d+)?)");
            if (m.Success) dur = int.Parse(m.Groups[1].Value) * 3600 + int.Parse(m.Groups[2].Value) * 60 + double.Parse(m.Groups[3].Value, Cfg.CI);
        }
        int tracks = Regex.Matches(sb.ToString(), @"Stream #\d+:\d+.*: Audio:").Count;
        var first = Regex.Match(sb.ToString(), @"title\s*:\s*Game (only|\+ mic)");
        bool micOn = !first.Success || first.Groups[1].Value != "only";
        try { File.WriteAllText(k + ".txt", dur.ToString(Cfg.CI) + "\n" + (tracks >= 2 ? "1" : "0") + "\n" + (micOn ? "1" : "0")); } catch { }
    }
}

// Anonymous user count: a random id per PC, the app version, and "open" or "clip". Nothing else.
static class Stats {
    const string Url = "https://tjqrsfefioxioosfowet.supabase.co/rest/v1/rpc/lumen_ping";
    public const string Key = "sb_publishable_-S8jl_XlODeemIzOP5lYvg_vAEZt6dz";
    public const string Version = "1.1";
    public static void Ping(string ev) {
        if (Cfg.Get("stats", "1") != "1") return;
        string id = Cfg.Get("id", "");
        if (id == "") { id = Guid.NewGuid().ToString(); Cfg.Set("id", id); }
        ThreadPool.QueueUserWorkItem(_ => {
            try {
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
                using (var wc = new WebClient()) {
                    wc.Headers["apikey"] = Key; wc.Headers["Content-Type"] = "application/json";
                    wc.UploadString(Url, "{\"p_id\":\"" + id + "\",\"p_version\":\"" + Version + "\",\"p_event\":\"" + ev + "\"}");
                }
            } catch { }
        });
    }
}

// A soft two-note chime, made in code so no sound file is needed.
static class Chime {
    static System.Media.SoundPlayer player;
    public static void Play() {
        if (Cfg.Get("sound", "1") != "1") return;
        try {
            if (player == null) { player = new System.Media.SoundPlayer(new MemoryStream(Make())); player.Load(); }
            player.Play();
        } catch { }
    }
    static double Note(double t, double f) {
        if (t < 0) return 0;
        double env = Math.Min(1, t / 0.005) * Math.Exp(-t * 8);
        return (Math.Sin(2 * Math.PI * f * t) + 0.2 * Math.Sin(4 * Math.PI * f * t) * Math.Exp(-t * 12)) * env;
    }
    static byte[] Make() {
        int rate = 44100, n = (int)(rate * 0.5);
        var ms = new MemoryStream(); var w = new BinaryWriter(ms);
        w.Write(Encoding.ASCII.GetBytes("RIFF")); w.Write(36 + n * 2); w.Write(Encoding.ASCII.GetBytes("WAVEfmt "));
        w.Write(16); w.Write((short)1); w.Write((short)1); w.Write(rate); w.Write(rate * 2); w.Write((short)2); w.Write((short)16);
        w.Write(Encoding.ASCII.GetBytes("data")); w.Write(n * 2);
        for (int i = 0; i < n; i++) {
            double t = (double)i / rate;
            double v = Note(t, 988) * 0.55 + Note(t - 0.075, 1319) * 0.45;
            w.Write((short)(v * 0.14 * 32767));
        }
        w.Flush(); return ms.ToArray();
    }
}

static class Updater {
    const string Api = "https://tjqrsfefioxioosfowet.supabase.co/rest/v1/lumen_release?select=version,url,notes&id=eq.1";
    public static string Latest, Url, Notes; public static bool HasUpdate;
    // Asks the Lumen server for the newest version. Returns null if it worked, else a reason.
    public static string Check() {
        try {
            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
            using (var wc = new WebClient()) {
                wc.Headers["apikey"] = Stats.Key; wc.Encoding = Encoding.UTF8;
                string j = wc.DownloadString(Api);
                Latest = J(j, "version"); Url = J(j, "url"); Notes = J(j, "notes") ?? "";
                Version a, b;
                HasUpdate = Latest != null && Url != null && Version.TryParse(Latest, out a) && Version.TryParse(Stats.Version, out b) && a > b;
                Cfg.Set("lastCheck", DateTime.Now.ToString("yyyy-MM-dd", Cfg.CI));
                return null;
            }
        } catch (Exception ex) { return ex.Message; }
    }
    static string J(string j, string k) {
        var m = Regex.Match(j, "\"" + k + "\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"");
        return m.Success ? Regex.Unescape(m.Groups[1].Value) : null;
    }
    // Downloads the new version, then a small helper swaps the files once Lumen has closed and opens it again.
    public static string Install() {
        try {
            string dir = Path.Combine(Cfg.Local, "update");
            if (Directory.Exists(dir)) Directory.Delete(dir, true);
            Directory.CreateDirectory(dir);
            string zip = Path.Combine(dir, "Lumen.zip"), x = Path.Combine(dir, "x");
            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
            using (var wc = new WebClient()) wc.DownloadFile(Url, zip);
            ZipFile.ExtractToDirectory(zip, x);
            string src = Directory.GetFiles(x, "Lumen.cs", SearchOption.AllDirectories).Select(Path.GetDirectoryName).FirstOrDefault();
            if (src == null) return "The download did not contain Lumen.";
            string app = Application.StartupPath; int pid = Process.GetCurrentProcess().Id;
            string bat = Path.Combine(dir, "update.bat");
            File.WriteAllText(bat,
                "@echo off\r\n" +
                ":wait\r\ntasklist /fi \"PID eq " + pid + "\" | find \"" + pid + "\" >nul && (timeout /t 1 /nobreak >nul & goto wait)\r\n" +
                "copy /y \"" + src + "\\*.*\" \"" + app + "\" >nul\r\n" +
                "del /f /q \"" + Path.Combine(app, "Lumen.exe") + "\"\r\n" +
                "cd /d \"" + app + "\"\r\nstart \"\" \"" + Path.Combine(app, "Open Lumen.bat") + "\"\r\n");
            var psi = new ProcessStartInfo("cmd.exe", "/c \"" + bat + "\""); psi.CreateNoWindow = true; psi.UseShellExecute = false;
            Process.Start(psi);
            return null;
        } catch (Exception ex) { return ex.Message; }
    }
}

class Clip {
    public string Path, Title; public DateTime When; public double Dur = -1; public Image Thumb; public bool Queued, HasMic, MicOn = true;
    public float Hov, Press; public DateTime Shown = DateTime.MinValue, Born = DateTime.MinValue, Copied = DateTime.MinValue;
}

// ---------- motion ----------
static class Anim {
    [DllImport("user32.dll")] static extern bool SystemParametersInfo(int a, int b, ref bool v, int c);
    public static readonly bool Reduced = CheckReduced();
    static bool CheckReduced() { try { bool on = true; SystemParametersInfo(0x1042, 0, ref on, 0); return !on; } catch { return false; } }
    static float C(float t) { return t < 0 ? 0 : t > 1 ? 1 : t; }
    public static float Out(float t) { t = C(t); return 1 - (float)Math.Pow(1 - t, 3); }
    public static float InOut(float t) { t = C(t); return t < 0.5f ? 4 * t * t * t : 1 - (float)Math.Pow(-2 * t + 2, 3) / 2; }
    public static float Back(float t) { t = C(t); float c1 = 1.5f, c3 = c1 + 1; return 1 + c3 * (float)Math.Pow(t - 1, 3) + c1 * (float)Math.Pow(t - 1, 2); }
    public static float To(float cur, float target, float dt, float speed) {
        if (Reduced) return target;
        float v = cur + (target - cur) * (1 - (float)Math.Exp(-speed * dt));
        return Math.Abs(v - target) < 0.004f ? target : v;
    }
    public static float Since(DateTime t, float ms) { return Reduced ? 1 : (float)((DateTime.Now - t).TotalMilliseconds / ms); }
    public static Rectangle Lerp(Rectangle a, Rectangle b, float t) {
        return new Rectangle((int)(a.X + (b.X - a.X) * t), (int)(a.Y + (b.Y - a.Y) * t), (int)(a.Width + (b.Width - a.Width) * t), (int)(a.Height + (b.Height - a.Height) * t));
    }
    public static void Cover(Graphics g, Image img, Rectangle r) {
        float s = Math.Max((float)r.Width / img.Width, (float)r.Height / img.Height);
        float w = img.Width * s, h = img.Height * s;
        g.DrawImage(img, r.X + (r.Width - w) / 2, r.Y + (r.Height - h) / 2, w, h);
    }
}

// ---------- clip gallery ----------
class Gallery : Canvas {
    public List<Clip> Clips = new List<Clip>();
    public event Action<string, Clip> Act;
    public int LengthSec = 30; public string KeyName = "F9";
    class Item { public Rectangle R; public Clip C; public string Head; public int Count; }
    List<Item> items = new List<Item>();
    Clip hover, pressed; bool hoverShare;
    ContextMenuStrip menu; Clip menuClip;
    System.Windows.Forms.Timer tm; DateTime last = DateTime.Now; DateTime emptyAt = DateTime.Now;

    public Gallery() {
        BackColor = T.Table; AutoScroll = true;
        menu = new ContextMenuStrip(); menu.Font = T.Body(10, false);
        foreach (var n in new[] { "Play", "Share", "Rename", "Mic", "Copy file", "Show in folder", "-", "Delete" }) {
            if (n == "-") { menu.Items.Add(new ToolStripSeparator()); continue; }
            string name = n;
            var item = menu.Items.Add(n, null, (s, e) => { if (Act != null && menuClip != null) Act(name, menuClip); }); item.Tag = name;
        }
        tm = new System.Windows.Forms.Timer { Interval = 15 };
        tm.Tick += (s, e) => Step();
    }
    public void Kick() { if (!tm.Enabled) { last = DateTime.Now; tm.Start(); } }
    void Step() {
        if (!Visible) { tm.Stop(); return; }
        var now = DateTime.Now; float dt = (float)(now - last).TotalSeconds; last = now;
        bool busy = false;
        foreach (var c in Clips) {
            float th = c == hover ? 1 : 0, tp = c == pressed ? 1 : 0;
            c.Hov = Anim.To(c.Hov, th, dt, 14); c.Press = Anim.To(c.Press, tp, dt, 26);
            if (c.Hov != th || c.Press != tp || Anim.Since(c.Shown, 420) < 1 || Anim.Since(c.Born, 1600) < 1) busy = true;
        }
        if (Clips.Count == 0 && Anim.Since(emptyAt, 3200) < 1) busy = true;
        Invalidate();
        if (!busy) tm.Stop();
    }
    // The one big moment: slides are laid on the table one after another.
    public void Intro() {
        var now = DateTime.Now; emptyAt = now;
        int i = 0;
        foreach (var it in items) if (it.C != null) it.C.Shown = now.AddMilliseconds(Math.Min(i++, 14) * 38);
        Kick();
    }
    public void Develop(Clip c) { c.Born = DateTime.Now; c.Shown = DateTime.Now; Kick(); }

    int M { get { return T.D(10); } }
    public void Relayout() {
        items.Clear();
        int pad = T.D(32), gap = T.D(22);
        int avail = Math.Max(T.D(200), ClientSize.Width - pad * 2);
        int cols = Math.Max(1, (avail + gap) / (T.D(236) + gap));
        int cw = Math.Min(T.D(340), (avail - (cols - 1) * gap) / cols);
        int th = (cw - M * 2) * 9 / 16, ch = M + th + T.D(58);
        int y = T.D(6);
        foreach (var grp in Clips.GroupBy(c => c.When.Date)) {
            var list = grp.ToList();
            items.Add(new Item { R = new Rectangle(pad, y, avail, T.D(40)), Head = DayName(grp.Key), Count = list.Count });
            y += T.D(48);
            for (int i = 0; i < list.Count; i++) {
                int col = i % cols, row = i / cols;
                items.Add(new Item { R = new Rectangle(pad + col * (cw + gap), y + row * (ch + gap), cw, ch), C = list[i] });
            }
            y += ((list.Count + cols - 1) / cols) * (ch + gap) + T.D(16);
        }
        var want = new Size(0, Clips.Count == 0 ? 0 : y + pad);
        if (AutoScrollMinSize != want) AutoScrollMinSize = want;
        Invalidate();
    }
    static string DayName(DateTime d) {
        if (d == DateTime.Today) return "Today";
        if (d == DateTime.Today.AddDays(-1)) return "Yesterday";
        return d.ToString(d.Year == DateTime.Today.Year ? "dddd d MMMM" : "d MMMM yyyy", CultureInfo.GetCultureInfo("en-GB"));
    }
    protected override void OnResize(EventArgs e) { base.OnResize(e); Relayout(); }

    Rectangle ThumbRect(Rectangle r) { return new Rectangle(r.X + M, r.Y + M, r.Width - M * 2, (r.Width - M * 2) * 9 / 16); }
    Rectangle ShareRect(Rectangle r) {
        var t = ThumbRect(r); int w = T.D(70), h = T.D(30);
        return new Rectangle(t.Right - w - T.D(8), t.Bottom - h - T.D(8), w, h);
    }
    // Where a clip's picture sits on screen right now (control coordinates).
    public Rectangle ThumbOnScreen(Clip c) {
        var it = items.FirstOrDefault(i => i.C == c);
        if (it == null) return new Rectangle(ClientSize.Width / 2 - T.D(100), ClientSize.Height / 2 - T.D(56), T.D(200), T.D(112));
        var t = ThumbRect(it.R); t.Offset(AutoScrollPosition.X, AutoScrollPosition.Y); return t;
    }
    public void ScrollTo(Clip c) {
        var it = items.FirstOrDefault(i => i.C == c); if (it == null) return;
        int top = -AutoScrollPosition.Y;
        if (it.R.Top < top || it.R.Bottom > top + ClientSize.Height) AutoScrollPosition = new Point(0, Math.Max(0, it.R.Top - T.D(60)));
    }
    Point Doc(Point p) { return new Point(p.X - AutoScrollPosition.X, p.Y - AutoScrollPosition.Y); }
    Item Hit(Point p) { var d = Doc(p); return items.FirstOrDefault(i => i.C != null && i.R.Contains(d)); }

    protected override void OnMouseMove(MouseEventArgs e) {
        base.OnMouseMove(e);
        var it = Hit(e.Location); var c = it == null ? null : it.C;
        bool sh = it != null && ShareRect(it.R).Contains(Doc(e.Location));
        if (c != hover || sh != hoverShare) { hover = c; hoverShare = sh; Cursor = c != null ? Cursors.Hand : Cursors.Default; Kick(); }
    }
    protected override void OnMouseLeave(EventArgs e) { base.OnMouseLeave(e); hover = null; pressed = null; Kick(); }
    protected override void OnMouseDown(MouseEventArgs e) {
        base.OnMouseDown(e); Focus();
        var it = Hit(e.Location); if (it != null && e.Button == MouseButtons.Left) { pressed = it.C; Kick(); }
    }
    protected override void OnMouseUp(MouseEventArgs e) {
        base.OnMouseUp(e);
        var was = pressed; pressed = null; Kick();
        var it = Hit(e.Location); if (it == null || Act == null) return;
        if (e.Button == MouseButtons.Right) {
            menuClip = it.C;
            foreach (ToolStripItem mi in menu.Items) if ((mi.Tag as string) == "Mic") { mi.Visible = it.C.HasMic; mi.Text = it.C.MicOn ? "Turn mic off" : "Turn mic on"; }
            menu.Show(this, e.Location); return;
        }
        if (e.Button == MouseButtons.Left && was == it.C) {
            if (ShareRect(it.R).Contains(Doc(e.Location))) { it.C.Copied = DateTime.Now; Act("Share", it.C); }
            else Act("Play", it.C);
        }
    }
    protected override void OnScroll(ScrollEventArgs se) { base.OnScroll(se); Invalidate(); }
    protected override void OnMouseWheel(MouseEventArgs e) { base.OnMouseWheel(e); Invalidate(); }

    protected override void OnPaint(PaintEventArgs e) {
        var g = e.Graphics; T.Hq(g); g.Clear(BackColor);
        if (Clips.Count == 0) { PaintEmpty(g); return; }
        g.TranslateTransform(AutoScrollPosition.X, AutoScrollPosition.Y);
        var view = new Rectangle(-AutoScrollPosition.X, -AutoScrollPosition.Y, ClientSize.Width, ClientSize.Height);
        foreach (var it in items) {
            if (!it.R.IntersectsWith(Rectangle.Inflate(view, 0, T.D(40)))) continue;
            if (it.C == null) {
                var f = T.Display(15);
                int w = TextRenderer.MeasureText(it.Head, f).Width;
                T.Text(g, it.Head, f, T.Ink, new Rectangle(it.R.X, it.R.Y, w + 4, it.R.Height), TextFormatFlags.Bottom);
                T.Text(g, it.Count == 1 ? "1 clip" : it.Count + " clips", T.Body(9.5f, false), T.Mute,
                    new Rectangle(it.R.X + w + T.D(12), it.R.Y, T.D(120), it.R.Height - T.D(2)), TextFormatFlags.Bottom);
            } else PaintCard(g, it.R, it.C);
        }
    }

    void PaintCard(Graphics g, Rectangle r0, Clip c) {
        float appear = Anim.Out(Anim.Since(c.Shown, 420));
        if (appear <= 0) return;
        float hv = Anim.InOut(c.Hov);
        var state = g.Save();
        // lift on hover, sink on press, rise in on arrival
        float dy = -T.D(4) * hv + (1 - appear) * T.D(22);
        float sc = 1 - 0.025f * c.Press + 0.01f * hv;
        float cx = r0.X + r0.Width / 2f, cy = r0.Y + r0.Height / 2f;
        g.TranslateTransform(cx, cy + dy); g.ScaleTransform(sc, sc); g.TranslateTransform(-cx, -cy);
        var r = r0; float rad = T.D(12);
        var rf = new RectangleF(r.X, r.Y, r.Width, r.Height);
        // the light-table glow
        if (hv > 0.01f)
            for (int i = 4; i >= 1; i--) {
                var gr = RectangleF.Inflate(rf, i * T.D(3.5f), i * T.D(3.5f));
                using (var p = T.Round(gr, rad + i * T.D(3.5f))) using (var b = new SolidBrush(Color.FromArgb((int)((12 + (4 - i) * 11) * hv), T.Lamp))) g.FillPath(b, p);
            }
        var sh = rf; sh.Offset(0, T.D(2) + T.D(6) * hv * (1 - hv * 0.5f));
        using (var p = T.Round(sh, rad)) using (var b = new SolidBrush(Color.FromArgb((int)(16 * (1 - hv)), T.Ink))) g.FillPath(b, p);
        using (var p = T.Round(rf, rad)) {
            g.FillPath(Brushes.White, p);
            using (var pen = new Pen(Blend(T.Line, T.Lamp, hv), 1 + T.D(1) * hv)) g.DrawPath(pen, p);
        }
        var tr = ThumbRect(r);
        using (var tp = T.Round(tr, T.D(6))) {
            var old = g.Clip; g.SetClip(tp, CombineMode.Intersect);
            using (var b = new SolidBrush(T.Ink2)) g.FillRectangle(b, tr);
            if (c.Thumb != null) {
                // slight zoom on hover, like leaning in
                var zr = Rectangle.Inflate(tr, (int)(tr.Width * 0.03f * hv), (int)(tr.Height * 0.03f * hv));
                Anim.Cover(g, c.Thumb, zr);
            } else T.Text(g, "Making preview", T.Body(9, false), T.Soft, tr, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            // a new clip develops: starts as pure light, settles into the picture
            float dev = Anim.Since(c.Born, 1600);
            if (dev < 1) {
                float k = 1 - Anim.Out(dev);
                using (var b = new SolidBrush(Color.FromArgb((int)(235 * k), 255, 248, 225))) g.FillRectangle(b, tr);
            }
            // duration tag
            if (c.Dur > 0) {
                string ds = Dur(c.Dur); var f = T.Body(9, true);
                int w = TextRenderer.MeasureText(ds, f).Width + T.D(14), h = T.D(22);
                var dr = new Rectangle(tr.X + T.D(8), tr.Bottom - h - T.D(8), w, h);
                using (var p = T.Round(dr, T.D(6))) using (var b = new SolidBrush(Color.FromArgb(190, T.Ink))) g.FillPath(b, p);
                T.Text(g, ds, f, Color.White, dr, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            }
            if (hv > 0.01f) {
                int d = (int)(T.D(46) * (0.7f + 0.3f * Anim.Back(c.Hov)));
                var cr = new Rectangle(tr.X + (tr.Width - d) / 2, tr.Y + (tr.Height - d) / 2, d, d);
                using (var b = new SolidBrush(Color.FromArgb((int)((c == hover && hoverShare ? 110 : 180) * hv), T.Ink))) g.FillEllipse(b, cr);
                float px = cr.X + d / 2f + d * 0.05f, py = cr.Y + d / 2f, a = d * 0.2f;
                using (var b = new SolidBrush(Color.FromArgb((int)(255 * hv), Color.White)))
                    g.FillPolygon(b, new[] { new PointF(px - a * 0.75f, py - a), new PointF(px - a * 0.75f, py + a), new PointF(px + a, py) });
                var sr = ShareRect(r); sr.Offset(0, (int)((1 - hv) * T.D(10)));
                bool copied = Anim.Since(c.Copied, 1400) < 1;
                using (var p = T.Round(sr, T.D(8)))
                using (var b = new SolidBrush(Color.FromArgb((int)(255 * hv), copied || (c == hover && hoverShare) ? T.Lamp : Color.White))) g.FillPath(b, p);
                T.Text(g, copied ? "Copied" : "Share", T.Body(9.5f, true), Blend(Color.White, T.Ink, hv), sr, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            }
            g.Clip = old;
        }
        int ty = tr.Bottom + T.D(11);
        T.Text(g, c.Title, T.Body(10.5f, true), T.Ink, new Rectangle(tr.X, ty, tr.Width, T.D(22)), TextFormatFlags.EndEllipsis);
        T.Text(g, c.When.ToString("HH:mm", Cfg.CI), T.Body(9.5f, false), T.Mute, new Rectangle(tr.X, ty + T.D(23), tr.Width, T.D(20)), TextFormatFlags.Left);
        g.Restore(state);
        if (appear < 1) {
            var cover = Rectangle.Inflate(r0, T.D(20), T.D(26));
            using (var b = new SolidBrush(Color.FromArgb((int)(255 * (1 - appear)), BackColor))) g.FillRectangle(b, cover);
        }
    }
    public static string Dur(double s) { int t = (int)Math.Round(s); return (t / 60) + ":" + (t % 60).ToString("00"); }
    public static Color Blend(Color a, Color b, float t) {
        t = Math.Max(0, Math.Min(1, t));
        return Color.FromArgb((int)(a.R + (b.R - a.R) * t), (int)(a.G + (b.G - a.G) * t), (int)(a.B + (b.B - a.B) * t));
    }

    void PaintEmpty(Graphics g) {
        float t = Anim.Since(emptyAt, 3200);
        int w = T.D(236), h = T.D(150);
        var r = new RectangleF((ClientSize.Width - w) / 2f, ClientSize.Height * 0.40f - h, w, h);
        // an empty slide that lights up once, then waits
        float glow = Anim.Reduced ? 0.4f : (float)Math.Sin(Math.Min(1, t) * Math.PI) * 0.8f + 0.25f * Math.Min(1, t * 3);
        for (int i = 4; i >= 1; i--) {
            var gr = RectangleF.Inflate(r, i * T.D(4), i * T.D(4));
            using (var p = T.Round(gr, T.D(12) + i * T.D(4))) using (var b = new SolidBrush(Color.FromArgb((int)((10 + (4 - i) * 9) * glow), T.Lamp))) g.FillPath(b, p);
        }
        using (var p = T.Round(r, T.D(12))) {
            using (var b = new SolidBrush(Color.FromArgb(150, Color.White))) g.FillPath(b, p);
            using (var pen = new Pen(T.Soft, T.D(1.5f))) { pen.DashPattern = new float[] { 4, 3 }; g.DrawPath(pen, p); }
        }
        int y = (int)r.Bottom + T.D(30);
        T.Text(g, "No clips yet", T.Display(17), T.Ink, new Rectangle(0, y, ClientSize.Width, T.D(30)), TextFormatFlags.HorizontalCenter);
        T.Text(g, "Play something and press " + KeyName + ". Lumen saves the last " + Cfg.LenText(LengthSec) + ".",
            T.Body(10.5f, false), T.Mute, new Rectangle(0, y + T.D(38), ClientSize.Width, T.D(24)), TextFormatFlags.HorizontalCenter);
    }
}

// ---------- built-in player (Windows Media Foundation) ----------
[StructLayout(LayoutKind.Explicit, Size = 24)] struct PropVar { [FieldOffset(0)] public ushort vt; [FieldOffset(8)] public long v; }
[ComImport, Guid("A714590A-58AF-430a-85BF-44F5EC838D85"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
interface IMFPMediaPlayer {
    [PreserveSig] int Play();
    [PreserveSig] int Pause();
    [PreserveSig] int Stop();
    [PreserveSig] int FrameStep();
    [PreserveSig] int SetPosition(ref Guid type, ref PropVar pos);
    [PreserveSig] int GetPosition(ref Guid type, ref PropVar pos);
    [PreserveSig] int GetDuration(ref Guid type, ref PropVar dur);
    [PreserveSig] int SetRate(float r);
    [PreserveSig] int GetRate(out float r);
    [PreserveSig] int GetSupportedRates(int fwd, out float a, out float b);
    [PreserveSig] int GetState(out int st);
    [PreserveSig] int CreateMediaItemFromURL([MarshalAs(UnmanagedType.LPWStr)] string url, int sync, IntPtr user, out IntPtr item);
    [PreserveSig] int CreateMediaItemFromObject(IntPtr obj, int sync, IntPtr user, out IntPtr item);
    [PreserveSig] int SetMediaItem(IntPtr item);
    [PreserveSig] int ClearMediaItem();
    [PreserveSig] int GetMediaItem(out IntPtr item);
    [PreserveSig] int GetVolume(out float v);
    [PreserveSig] int SetVolume(float v);
    [PreserveSig] int GetBalance(out float v);
    [PreserveSig] int SetBalance(float v);
    [PreserveSig] int GetMute(out int m);
    [PreserveSig] int SetMute(int m);
    [PreserveSig] int GetNativeVideoSize(IntPtr a, IntPtr b);
    [PreserveSig] int GetIdealVideoSize(IntPtr a, IntPtr b);
    [PreserveSig] int SetVideoSourceRect(IntPtr r);
    [PreserveSig] int GetVideoSourceRect(IntPtr r);
    [PreserveSig] int SetAspectRatioMode(int m);
    [PreserveSig] int GetAspectRatioMode(out int m);
    [PreserveSig] int GetVideoWindow(out IntPtr h);
    [PreserveSig] int UpdateVideo();
    [PreserveSig] int SetBorderColor(int c);
    [PreserveSig] int GetBorderColor(out int c);
    [PreserveSig] int InsertEffect(IntPtr e, int opt);
    [PreserveSig] int RemoveEffect(IntPtr e);
    [PreserveSig] int RemoveAllEffects();
    [PreserveSig] int Shutdown();
}

class VideoHost : Panel {
    public VideoHost() { BackColor = T.Ink; SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint, true); }
    protected override void OnPaintBackground(PaintEventArgs e) { }
}

class PlayerView : Canvas {
    [DllImport("mfplay.dll", CharSet = CharSet.Unicode, ExactSpelling = true)]
    static extern int MFPCreateMediaPlayer(string url, int start, int opts, IntPtr cb, IntPtr hwnd, out IMFPMediaPlayer mp);
    [DllImport("mfplat.dll", ExactSpelling = true)] static extern int MFStartup(int version, int flags);
    static bool mfStarted;

    public VideoHost Host = new VideoHost();
    public Clip Clip; public event Action<string, Clip> Act; public event Action Closed;
    public Func<Clip, Rectangle> CardRect; public Bitmap Backdrop;
    Btn back, share, ren, nomic, del;
    IMFPMediaPlayer mp; System.Windows.Forms.Timer tm; DateTime last = DateTime.Now, seekSent = DateTime.MinValue;
    double dur, pos; bool playing, muted, dragging, ended;
    float morph, scrubHov, playHov, muteHov;
    int animDir; DateTime animAt; Rectangle from;
    Rectangle playR, scrubR, muteR, stageR;

    public PlayerView() {
        BackColor = T.Table;
        Host.Visible = false;
        Host.Paint += (s, e) => { if (mp != null) mp.UpdateVideo(); };
        Host.Resize += (s, e) => { if (mp != null) mp.UpdateVideo(); };
        Host.MouseUp += (s, e) => { if (e.Button == MouseButtons.Left) Toggle(); };
        Controls.Add(Host);
        back = new Btn("Back to clips", false); back.Click += (s, e) => Close();
        share = new Btn("Share", true); share.Click += (s, e) => { if (Act != null) Act("Share", Clip); };
        ren = new Btn("Rename", false); ren.Click += (s, e) => { if (Act != null) Act("Rename", Clip); };
        nomic = new Btn("Turn mic off", false); nomic.Click += (s, e) => { if (Act != null) Act("Mic", Clip); };
        del = new Btn("Delete", false); del.Click += (s, e) => { if (Act != null) Act("Delete", Clip); };
        Controls.AddRange(new Control[] { back, share, ren, nomic, del });
        tm = new System.Windows.Forms.Timer { Interval = 15 }; tm.Tick += (s, e) => Step();
    }
    public bool Busy { get { return animDir != 0; } }

    void Place() {
        int pad = T.D(32);
        back.Location = new Point(pad, T.D(6));
        int top = T.D(62), bottom = ClientSize.Height - T.D(92);
        int aw = ClientSize.Width - pad * 2, ah = Math.Max(T.D(100), bottom - top);
        int w = aw, h = w * 9 / 16; if (h > ah) { h = ah; w = h * 16 / 9; }
        stageR = new Rectangle((ClientSize.Width - w) / 2, top + (ah - h) / 2, w, h);
        Host.Bounds = stageR;
        using (var p = T.Round(new RectangleF(0, 0, w, h), T.D(14))) Host.Region = new Region(p);
        int cy = stageR.Bottom + T.D(46);
        playR = new Rectangle(stageR.X, cy - T.D(24), T.D(48), T.D(48));
        int bx = stageR.Right;
        foreach (var b in new[] { del, nomic, ren, share }) { if (b == nomic && (Clip == null || !Clip.HasMic)) continue; bx -= b.Width; b.Location = new Point(bx, cy - b.Height / 2); bx -= T.D(10); }
        muteR = new Rectangle(bx - T.D(36), cy - T.D(18), T.D(36), T.D(36));
        int sx = playR.Right + T.D(68), ex = muteR.X - T.D(68);
        scrubR = new Rectangle(sx, cy - T.D(12), Math.Max(T.D(40), ex - sx), T.D(24));
    }
    protected override void OnResize(EventArgs e) { base.OnResize(e); Place(); Invalidate(); }

    public void Open(Clip c) {
        Clip = c; dur = c.Dur > 0 ? c.Dur : 0; pos = 0; ended = false; playing = false; morph = 0;
        Place();
        from = CardRect != null ? CardRect(c) : stageR;
        Host.Visible = false;
        animDir = 1; animAt = DateTime.Now;
        SetButtons(0);
        CreateMp();
        last = DateTime.Now; tm.Start(); Invalidate();
    }
    void CreateMp() {
        try {
            if (!mfStarted) { MFStartup(0x20070, 0); mfStarted = true; }
            IMFPMediaPlayer p;
            int hr = MFPCreateMediaPlayer(Clip.Path, 0, 0, IntPtr.Zero, Host.Handle, out p);
            if (hr == 0) { mp = p; mp.SetBorderColor(ColorTranslator.ToWin32(T.Ink)); mp.SetMute(muted ? 1 : 0); }
        } catch { mp = null; }
    }
    // After the file changed (renamed, mic removed): load it again and keep playing.
    public void Reopen() {
        Release(); dur = Clip.Dur > 0 ? Clip.Dur : 0; pos = 0; ended = false;
        CreateMp(); SetButtons(1);
        if (mp != null) { mp.UpdateVideo(); mp.Play(); playing = true; }
        Invalidate();
    }
    public void Close() {
        if (animDir != 0 || Clip == null) return;
        if (mp != null) mp.Pause();
        Host.Visible = false;
        from = CardRect != null ? CardRect(Clip) : stageR;
        animDir = -1; animAt = DateTime.Now; SetButtons(0); Invalidate();
    }
    public void Release() {
        if (mp != null) { try { mp.Shutdown(); Marshal.ReleaseComObject(mp); } catch { } mp = null; }
    }
    public void CloseNow() { Release(); animDir = 0; Host.Visible = false; tm.Stop(); if (Closed != null) Closed(); }
    void SetButtons(float a) {
        bool v = a >= 1; foreach (var b in new Control[] { back, share, ren, del }) b.Visible = v;
        nomic.Visible = v && Clip != null && Clip.HasMic;
        if (Clip != null) { nomic.Text = Clip.MicOn ? "Turn mic off" : "Turn mic on"; nomic.Fit(); nomic.Invalidate(); }
        Place();
    }

    public void Toggle() {
        if (mp == null || animDir != 0) return;
        if (playing) mp.Pause();
        else { if (ended || (dur > 0 && pos >= dur - 0.15)) SeekTo(0); mp.Play(); ended = false; }
        playing = !playing; Invalidate();
    }
    public void Skip(double s) { if (mp != null) { SeekTo(Math.Max(0, Math.Min(dur, pos + s))); Invalidate(); } }
    void SeekTo(double s) {
        if (mp == null) return;
        var g = Guid.Empty; var pv = new PropVar { vt = 20, v = (long)(s * 1e7) };
        mp.SetPosition(ref g, ref pv); pos = s; seekSent = DateTime.Now;
    }
    public void ToggleMute() { muted = !muted; if (mp != null) mp.SetMute(muted ? 1 : 0); Invalidate(); }

    void Step() {
        var now = DateTime.Now; float dt = (float)(now - last).TotalSeconds; last = now;
        if (animDir != 0) {
            float t = Anim.Since(animAt, 340);
            if (t >= 1) {
                if (animDir == 1) {
                    animDir = 0; SetButtons(1); Host.Visible = true;
                    if (mp != null) { mp.UpdateVideo(); mp.Play(); playing = true; }
                    Focus();
                } else {
                    animDir = 0; Release(); tm.Stop();
                    if (Closed != null) Closed();
                    return;
                }
            }
            Invalidate(); return;
        }
        if (!Visible) { tm.Stop(); return; }
        if (mp != null) {
            var g = Guid.Empty; var pv = new PropVar();
            if (dur <= 0 && mp.GetDuration(ref g, ref pv) == 0) dur = pv.v / 1e7;
            if (!dragging && (now - seekSent).TotalMilliseconds > 250) { pv = new PropVar(); if (mp.GetPosition(ref g, ref pv) == 0) pos = pv.v / 1e7; }
            int st; if (mp.GetState(out st) == 0 && playing && st == 1) { playing = false; ended = true; pos = dur; }
        }
        var m = PointToClient(MousePosition);
        morph = Anim.To(morph, playing ? 1 : 0, dt, 18);
        scrubHov = Anim.To(scrubHov, dragging || Rectangle.Inflate(scrubR, 0, T.D(6)).Contains(m) ? 1 : 0, dt, 16);
        playHov = Anim.To(playHov, playR.Contains(m) ? 1 : 0, dt, 16);
        muteHov = Anim.To(muteHov, muteR.Contains(m) ? 1 : 0, dt, 16);
        Invalidate(new Rectangle(0, stageR.Bottom, ClientSize.Width, ClientSize.Height - stageR.Bottom));
    }

    protected override void OnMouseMove(MouseEventArgs e) {
        base.OnMouseMove(e);
        if (dragging) Scrub(e.X);
        Cursor = playR.Contains(e.Location) || muteR.Contains(e.Location) || Rectangle.Inflate(scrubR, 0, T.D(6)).Contains(e.Location) ? Cursors.Hand : Cursors.Default;
    }
    protected override void OnMouseDown(MouseEventArgs e) {
        base.OnMouseDown(e); Focus();
        if (animDir != 0 || e.Button != MouseButtons.Left) return;
        if (Rectangle.Inflate(scrubR, 0, T.D(6)).Contains(e.Location)) { dragging = true; Scrub(e.X); }
    }
    protected override void OnMouseUp(MouseEventArgs e) {
        base.OnMouseUp(e);
        if (dragging) { dragging = false; Scrub(e.X); SeekTo(pos); ended = false; return; }
        if (animDir != 0) return;
        if (playR.Contains(e.Location)) Toggle();
        else if (muteR.Contains(e.Location)) ToggleMute();
    }
    void Scrub(int x) {
        if (dur <= 0) return;
        pos = Math.Max(0, Math.Min(dur, (x - scrubR.X) / (double)scrubR.Width * dur));
        if ((DateTime.Now - seekSent).TotalMilliseconds > 60) SeekTo(pos);
        Invalidate(new Rectangle(0, stageR.Bottom, ClientSize.Width, ClientSize.Height - stageR.Bottom));
    }

    protected override void OnPaint(PaintEventArgs e) {
        var g = e.Graphics; T.Hq(g); g.Clear(BackColor);
        float a = 1;
        if (animDir != 0) {
            float t = Anim.InOut(Anim.Since(animAt, 340));
            a = animDir == 1 ? t : 1 - t;
            if (Backdrop != null) {
                g.DrawImageUnscaled(Backdrop, 0, 0);
                using (var b = new SolidBrush(Color.FromArgb((int)(255 * a), BackColor))) g.FillRectangle(b, ClientRectangle);
            }
            // the clip's picture flies from its slide to the stage
            var r = Anim.Lerp(from, stageR, a);
            using (var p = T.Round(r, T.D(6) + T.D(8) * a)) {
                var old = g.Clip; g.SetClip(p, CombineMode.Intersect);
                using (var b = new SolidBrush(T.Ink)) g.FillRectangle(b, r);
                if (Clip != null && Clip.Thumb != null) Anim.Cover(g, Clip.Thumb, r);
                g.Clip = old;
            }
        } else {
            using (var p = T.Round(stageR, T.D(14))) using (var b = new SolidBrush(T.Ink)) g.FillPath(b, p);
        }
        if (Clip == null || a < 0.6f) return;
        // header line
        int tx = T.D(32) + back.Width + T.D(18);
        var tf = T.Display(16);
        T.Text(g, Clip.Title, tf, Fade(T.Ink, a), new Rectangle(tx, T.D(6), Math.Max(10, ClientSize.Width - tx - T.D(200)), back.Height), TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
        T.Text(g, Clip.When.ToString("d MMM, HH:mm", CultureInfo.GetCultureInfo("en-GB")), T.Body(10, false), Fade(T.Mute, a),
            new Rectangle(stageR.Right - T.D(200), T.D(6), T.D(200), back.Height), TextFormatFlags.VerticalCenter | TextFormatFlags.Right);
        float ca = animDir == 0 ? 1 : a;
        // play / pause button: the icon morphs
        float grow = 1 + 0.06f * playHov;
        var pr = RectangleF.Inflate(playR, playR.Width * (grow - 1) / 2, playR.Height * (grow - 1) / 2);
        using (var b = new SolidBrush(Fade(Gallery.Blend(T.Ink, T.Ink2, playHov), ca))) g.FillEllipse(b, pr);
        float cx = pr.X + pr.Width / 2, cy = pr.Y + pr.Height / 2, s = T.D(9);
        float mo = Anim.InOut(morph);
        using (var b = new SolidBrush(Color.FromArgb((int)(255 * ca * (1 - mo)), Color.White))) {
            float k = 1 - mo * 0.5f;
            g.FillPolygon(b, new[] { new PointF(cx - s * 0.65f * k + T.D(1.5f), cy - s * k), new PointF(cx - s * 0.65f * k + T.D(1.5f), cy + s * k), new PointF(cx + s * k + T.D(1.5f), cy) });
        }
        using (var b = new SolidBrush(Color.FromArgb((int)(255 * ca * mo), Color.White))) {
            float k = 0.5f + mo * 0.5f, bw = T.D(4) * k, bh = s * 2 * k, gap = T.D(3.5f) * k;
            g.FillRectangle(b, cx - gap - bw, cy - bh / 2, bw, bh); g.FillRectangle(b, cx + gap, cy - bh / 2, bw, bh);
        }
        // times
        var nf = T.Body(10, true);
        T.Text(g, Gallery.Dur(pos), nf, Fade(T.Ink, ca), new Rectangle(playR.Right + T.D(14), playR.Y, T.D(50), playR.Height), TextFormatFlags.VerticalCenter);
        T.Text(g, Gallery.Dur(dur), nf, Fade(T.Mute, ca), new Rectangle(scrubR.Right + T.D(14), playR.Y, T.D(50), playR.Height), TextFormatFlags.VerticalCenter);
        // scrubber
        float th = T.D(4) + T.D(3) * scrubHov, my = scrubR.Y + scrubR.Height / 2f;
        var track = new RectangleF(scrubR.X, my - th / 2, scrubR.Width, th);
        using (var p = T.Round(track, th / 2)) using (var b = new SolidBrush(Fade(T.Line, ca))) g.FillPath(b, p);
        float frac = dur > 0 ? (float)Math.Min(1, pos / dur) : 0;
        if (frac > 0) {
            var fill = track; fill.Width = Math.Max(th, track.Width * frac);
            using (var p = T.Round(fill, th / 2)) using (var b = new SolidBrush(Fade(T.Ink, ca))) g.FillPath(b, p);
        }
        float kx = track.X + track.Width * frac, kr = T.D(6) + T.D(3) * scrubHov;
        if (scrubHov > 0.01f) using (var b = new SolidBrush(Color.FromArgb((int)(70 * scrubHov * ca), T.Lamp))) g.FillEllipse(b, kx - kr * 2, my - kr * 2, kr * 4, kr * 4);
        using (var b = new SolidBrush(Fade(T.Lamp, ca))) g.FillEllipse(b, kx - kr, my - kr, kr * 2, kr * 2);
        // sound on/off
        if (muteHov > 0.01f) using (var b = new SolidBrush(Color.FromArgb((int)(255 * muteHov * ca), Color.White))) g.FillEllipse(b, muteR);
        using (var pen = new Pen(Fade(T.Ink, ca), T.D(1.6f))) using (var b = new SolidBrush(Fade(T.Ink, ca))) {
            float mx = muteR.X + muteR.Width / 2f - T.D(4), mmy = muteR.Y + muteR.Height / 2f;
            g.FillPolygon(b, new[] { new PointF(mx - T.D(6), mmy - T.D(3)), new PointF(mx - T.D(3), mmy - T.D(3)), new PointF(mx + T.D(2), mmy - T.D(7)),
                new PointF(mx + T.D(2), mmy + T.D(7)), new PointF(mx - T.D(3), mmy + T.D(3)), new PointF(mx - T.D(6), mmy + T.D(3)) });
            if (muted) { g.DrawLine(pen, mx + T.D(6), mmy - T.D(4), mx + T.D(12), mmy + T.D(4)); g.DrawLine(pen, mx + T.D(12), mmy - T.D(4), mx + T.D(6), mmy + T.D(4)); }
            else { g.DrawArc(pen, mx, mmy - T.D(5), T.D(9), T.D(10), -50, 100); g.DrawArc(pen, mx - T.D(1), mmy - T.D(9), T.D(15), T.D(18), -50, 100); }
        }
    }
    Color Fade(Color c, float a) { return Color.FromArgb((int)(255 * Math.Max(0, Math.Min(1, a))), c); }
}

// ---------- first-run setup (downloads ffmpeg) ----------
class SetupView : Canvas {
    public Btn Go = new Btn("Download ffmpeg", true);
    public int Progress = -1; public string Error;
    public SetupView() {
        BackColor = T.Table; Controls.Add(Go);
    }
    protected override void OnResize(EventArgs e) { base.OnResize(e); Go.Location = new Point(Col.X, Col.Y + T.D(118)); }
    Rectangle Col { get { int w = Math.Min(T.D(480), ClientSize.Width - T.D(64)); return new Rectangle((ClientSize.Width - w) / 2, (int)(ClientSize.Height * 0.25f), w, T.D(300)); } }
    protected override void OnPaint(PaintEventArgs e) {
        var g = e.Graphics; T.Hq(g); g.Clear(BackColor);
        var c = Col;
        T.Text(g, "One quick setup", T.Display(18), T.Ink, new Rectangle(c.X, c.Y, c.Width, T.D(34)), TextFormatFlags.Left);
        T.Text(g, "Lumen records with ffmpeg, a free video tool. It downloads once (about 90 MB) and stays on this PC.",
            T.Body(10.5f, false), T.Mute, new Rectangle(c.X, c.Y + T.D(44), c.Width, T.D(60)), TextFormatFlags.WordBreak);
        int y = c.Y + T.D(176);
        if (Progress >= 0) {
            var track = new RectangleF(c.X, y, c.Width, T.D(6));
            using (var p = T.Round(track, T.D(3))) using (var b = new SolidBrush(T.Line)) g.FillPath(b, p);
            if (Progress > 0) {
                var fill = track; fill.Width = Math.Max(T.D(6), track.Width * Progress / 100f);
                using (var p = T.Round(fill, T.D(3))) using (var b = new SolidBrush(T.Ink)) g.FillPath(b, p);
            }
            T.Text(g, Progress >= 100 ? "Unpacking…" : "Downloading " + Progress + "%", T.Body(9.5f, false), T.Mute,
                new Rectangle(c.X, y + T.D(14), c.Width, T.D(22)), TextFormatFlags.Left);
        } else if (Error != null) {
            T.Text(g, "Download failed: " + Error + " Check your internet and try again.", T.Body(10, false), T.Stop,
                new Rectangle(c.X, y, c.Width, T.D(48)), TextFormatFlags.WordBreak);
        }
        T.Text(g, "Already have ffmpeg? Put ffmpeg.exe next to Lumen.exe and open Lumen again.", T.Body(9.5f, false), T.Mute,
            new Rectangle(c.X, y + T.D(60), c.Width, T.D(40)), TextFormatFlags.WordBreak);
    }
}

// ---------- toast ----------
class Toast : Form {
    static Toast current;
    string a, b; bool ok; System.Windows.Forms.Timer tm; int tick, baseX;
    public static void Show(string a, string b, bool ok) {
        if (current != null && !current.IsDisposed) current.Close();
        current = new Toast(a, b, ok); current.Show();
    }
    Toast(string a, string b, bool ok) {
        this.a = a; this.b = b; this.ok = ok;
        FormBorderStyle = FormBorderStyle.None; ShowInTaskbar = false; TopMost = true; StartPosition = FormStartPosition.Manual;
        BackColor = T.Ink; DoubleBuffered = true; Opacity = 0;
        int w = Math.Max(T.D(300), TextRenderer.MeasureText(b, T.Body(9.5f, false)).Width + T.D(64));
        Size = new Size(Math.Min(w, T.D(460)), T.D(70));
        var wa = Screen.PrimaryScreen.WorkingArea;
        baseX = wa.Right - Width - T.D(20);
        Location = new Point(baseX + T.D(60), wa.Bottom - Height - T.D(20));
        using (var p = T.Round(new RectangleF(0, 0, Width, Height), T.D(10))) Region = new Region(p);
        tm = new System.Windows.Forms.Timer(); tm.Interval = 16;
        tm.Tick += (s, e) => {
            tick++;
            if (tick <= 22) {
                float t = tick / 22f; Opacity = Math.Min(1, t * 2);
                Left = baseX + (int)((1 - Anim.Back(t)) * T.D(60));
            }
            else if (tick > 170) { Opacity = Math.Max(0, 1 - (tick - 170) / 15.0); if (tick >= 185) { tm.Stop(); Close(); } }
        };
        tm.Start();
        Click += (s, e) => Close();
    }
    protected override bool ShowWithoutActivation { get { return true; } }
    protected override CreateParams CreateParams { get { var cp = base.CreateParams; cp.ExStyle |= 0x08000000 | 0x80 | 0x8; return cp; } }
    protected override void OnPaint(PaintEventArgs e) {
        var g = e.Graphics; T.Hq(g);
        int d = T.D(10);
        using (var br = new SolidBrush(ok ? T.Lamp : T.Stop)) g.FillEllipse(br, T.D(20), T.D(20), d, d);
        T.Text(g, a, T.Body(10.5f, true), Color.White, new Rectangle(T.D(42), T.D(13), Width - T.D(56), T.D(22)), TextFormatFlags.EndEllipsis);
        T.Text(g, b, T.Body(9.5f, false), T.Soft, new Rectangle(T.D(42), T.D(37), Width - T.D(56), T.D(22)), TextFormatFlags.EndEllipsis);
    }
    protected override void Dispose(bool disposing) { if (disposing && tm != null) tm.Dispose(); base.Dispose(disposing); }
}

// ---------- settings window ----------
class SettingsForm : Form {
    ComboBox key, len, q, fps, scr; TextBox folder; CheckBox auto, stats, micBox, soundBox; Label upd;
    static readonly int[] Lens = { 15, 30, 60, 120 };
    public SettingsForm() {
        Text = "Lumen settings"; FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false; MinimizeBox = false;
        StartPosition = FormStartPosition.CenterParent; ShowInTaskbar = false; AutoScaleMode = AutoScaleMode.None;
        BackColor = T.Table; Font = T.Body(10, false); ForeColor = T.Ink; Icon = T.MakeIcon(32);
        ClientSize = new Size(T.D(470), T.D(656));
        int y = T.D(26);
        key = Row("Clip key", ref y, new[] { "F6", "F7", "F8", "F9", "F10", "F11", "F12", "Alt+F9", "Alt+F10", "Ctrl+F9" }, Cfg.Key);
        len = Row("Clip length", ref y, Lens.Select(Cfg.LenText).ToArray(), Cfg.LenText(Cfg.Length));
        q = Row("Quality", ref y, new[] { "High", "Normal", "Small files" }, Cfg.Quality == "Small" ? "Small files" : Cfg.Quality);
        fps = Row("Frame rate", ref y, new[] { "60 fps", "30 fps" }, Cfg.Fps + " fps");
        scr = Row("Screen", ref y, Screen.AllScreens.Select((s, i) => "Screen " + (i + 1) + (s.Primary ? " (main)" : "")).ToArray(), null);
        scr.SelectedIndex = Math.Min(Cfg.Screen, scr.Items.Count - 1);
        Controls.Add(new Label { Text = "Clips folder", Location = new Point(T.D(26), y + T.D(5)), AutoSize = true });
        folder = new TextBox { Text = Cfg.ClipDir, ReadOnly = true, Location = new Point(T.D(170), y + T.D(2)), Width = T.D(180), BorderStyle = BorderStyle.FixedSingle, BackColor = Color.White };
        Controls.Add(folder);
        var change = new Btn("Change", false); change.Location = new Point(T.D(358), y - T.D(4)); change.Width = T.D(86);
        change.Click += (s, e) => {
            using (var fb = new FolderBrowserDialog { SelectedPath = folder.Text, Description = "Pick where Lumen saves your clips." })
                if (fb.ShowDialog(this) == DialogResult.OK) folder.Text = fb.SelectedPath;
        };
        Controls.Add(change);
        y += T.D(52);
        auto = new CheckBox { Text = "Start Lumen with Windows", Checked = AutoStart, Location = new Point(T.D(170), y), AutoSize = true };
        Controls.Add(auto);
        stats = new CheckBox { Text = "Count me as a Lumen user (anonymous)", Checked = Cfg.Get("stats", "1") == "1", Location = new Point(T.D(170), y + T.D(32)), AutoSize = true };
        Controls.Add(stats);
        micBox = new CheckBox { Text = "Record my mic in clips", Checked = Cfg.Get("mic", "1") == "1", Location = new Point(T.D(170), y + T.D(64)), AutoSize = true };
        Controls.Add(micBox);
        var micTip = new Label { Text = "Hear your own voice in your headset? Turn off mic monitoring (sidetone), or your voice also lands in the game sound and Turn mic off can't remove it.",
            ForeColor = T.Mute, Font = T.Body(8.5f, false), AutoSize = false, Location = new Point(T.D(188), y + T.D(86)), Size = new Size(T.D(260), T.D(48)) };
        Controls.Add(micTip);
        soundBox = new CheckBox { Text = "Play a soft sound when a clip is saved", Checked = Cfg.Get("sound", "1") == "1", Location = new Point(T.D(170), y + T.D(140)), AutoSize = true };
        Controls.Add(soundBox);
        var chk = new Btn("Check for updates", false); chk.Location = new Point(T.D(24), ClientSize.Height - chk.Height - T.D(22));
        upd = new Label { AutoSize = false, Location = new Point(T.D(26), chk.Top - T.D(30)), Size = new Size(T.D(420), T.D(24)), ForeColor = T.Mute, Text = "You have Lumen " + Stats.Version + "." };
        chk.Click += (s, e) => {
            upd.Text = "Checking…"; upd.Refresh(); Cursor = Cursors.WaitCursor;
            string err = Updater.Check(); Cursor = Cursors.Default;
            upd.Text = err != null ? "Could not check. Are you online?" : Updater.HasUpdate ? "Lumen " + Updater.Latest + " is out. Click Update in the top bar." : "You have the latest version (" + Stats.Version + ").";
            upd.ForeColor = Updater.HasUpdate ? T.Ink : T.Mute;
        };
        Controls.Add(chk); Controls.Add(upd);
        var save = new Btn("Save settings", true); var cancel = new Btn("Cancel", false);
        save.Location = new Point(ClientSize.Width - save.Width - T.D(24), ClientSize.Height - save.Height - T.D(22));
        cancel.Location = new Point(save.Left - cancel.Width - T.D(10), save.Top);
        save.Click += (s, e) => { Apply(); DialogResult = DialogResult.OK; Close(); };
        cancel.Click += (s, e) => Close();
        Controls.Add(save); Controls.Add(cancel);
    }
    ComboBox Row(string label, ref int y, string[] items, string sel) {
        Controls.Add(new Label { Text = label, Location = new Point(T.D(26), y + T.D(5)), AutoSize = true });
        var c = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, FlatStyle = FlatStyle.Flat, Location = new Point(T.D(170), y), Width = T.D(274) };
        c.Items.AddRange(items);
        if (sel != null) c.SelectedItem = sel;
        if (c.SelectedIndex < 0 && c.Items.Count > 0) c.SelectedIndex = 0;
        Controls.Add(c); y += T.D(46); return c;
    }
    const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";
    static bool AutoStart {
        get { try { using (var k = Registry.CurrentUser.OpenSubKey(RunKey)) return k != null && k.GetValue("Lumen") != null; } catch { return false; } }
    }
    void Apply() {
        Cfg.Set("key", key.SelectedItem);
        Cfg.Set("length", Lens[len.SelectedIndex]);
        Cfg.Set("quality", q.SelectedIndex == 2 ? "Small" : (string)q.SelectedItem);
        Cfg.Set("fps", fps.SelectedIndex == 0 ? 60 : 30);
        Cfg.Set("screen", Math.Max(0, scr.SelectedIndex));
        Cfg.Set("folder", folder.Text);
        Cfg.Set("stats", stats.Checked ? "1" : "0");
        Cfg.Set("mic", micBox.Checked ? "1" : "0");
        Cfg.Set("sound", soundBox.Checked ? "1" : "0");
        try {
            using (var k = Registry.CurrentUser.CreateSubKey(RunKey)) {
                if (auto.Checked) k.SetValue("Lumen", "\"" + Application.ExecutablePath + "\" /tray");
                else if (k.GetValue("Lumen") != null) k.DeleteValue("Lumen");
            }
        } catch { }
    }
}

// ---------- opening screen: the logo waits in the middle; click it and it flies into the top bar ----------
class Splash : Canvas {
    public event Action Clicked, Done;
    public Bitmap HeadShot; public int HeadH;
    System.Windows.Forms.Timer tm; DateTime t0 = DateTime.Now, go = DateTime.MinValue; bool started; float hov; DateTime last = DateTime.Now;
    public Splash() {
        BackColor = T.Table; TabStop = true;
        tm = new System.Windows.Forms.Timer { Interval = 15 }; tm.Tick += (s, e) => Step(); tm.Start();
    }
    const float Ms = 1000;
    Rectangle LogoRect() {
        var f = T.Display(44); int tw = TextRenderer.MeasureText("Lumen", f).Width, r = T.D(16), w = r * 2 + T.D(22) + tw, h = T.D(70);
        return new Rectangle((ClientSize.Width - w) / 2, (int)(ClientSize.Height * 0.44f) - h / 2, w, h);
    }
    void Step() {
        float dt = (float)(DateTime.Now - last).TotalSeconds; last = DateTime.Now;
        var m = PointToClient(MousePosition);
        hov = Anim.To(hov, !started && Rectangle.Inflate(LogoRect(), T.D(20), T.D(20)).Contains(m) ? 1 : 0, dt, 12);
        Cursor = !started && Rectangle.Inflate(LogoRect(), T.D(20), T.D(20)).Contains(m) ? Cursors.Hand : Cursors.Default;
        if (started && Anim.Since(go, Ms) >= 1) { tm.Stop(); if (Done != null) Done(); return; }
        Invalidate();
    }
    public void Start() {
        if (started) return;
        started = true; go = DateTime.Now; if (Clicked != null) Clicked();
    }
    protected override void OnMouseUp(MouseEventArgs e) { base.OnMouseUp(e); if (Rectangle.Inflate(LogoRect(), T.D(20), T.D(20)).Contains(e.Location)) Start(); }
    protected override void OnKeyDown(KeyEventArgs e) { base.OnKeyDown(e); if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Space) Start(); }
    protected override bool IsInputKey(Keys k) { return k == Keys.Space || k == Keys.Enter || base.IsInputKey(k); }
    protected override void OnPaint(PaintEventArgs e) {
        var g = e.Graphics; T.Hq(g); g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit; g.Clear(BackColor);
        float p = started ? Anim.Since(go, Ms) : 0;
        float mv = Anim.InOut((p - 0.14f) / 0.62f), fadeIn = Anim.Out((p - 0.5f) / 0.4f), ring = Anim.Out(p / 0.42f);
        var lr = LogoRect();
        // rest and target positions of lamp and word
        float r0 = T.D(16), r1 = T.D(8);
        PointF l0 = new PointF(lr.X + r0, lr.Y + lr.Height / 2f), l1 = new PointF(T.D(32) + r1, HeadH / 2f);
        float s0 = 44, s1 = 21; float x0 = lr.X + r0 * 2 + T.D(22), x1 = T.D(32) + T.D(30);
        float r = r0 + (r1 - r0) * mv, size = s0 + (s1 - s0) * mv;
        var lc = new PointF(l0.X + (l1.X - l0.X) * mv, l0.Y + (l1.Y - l0.Y) * mv);
        float tx = x0 + (x1 - x0) * mv;
        // the top bar fades in under the flying logo
        if (HeadShot != null && fadeIn > 0) {
            using (var ia = new System.Drawing.Imaging.ImageAttributes()) {
                var cm = new System.Drawing.Imaging.ColorMatrix(); cm.Matrix33 = fadeIn; ia.SetColorMatrix(cm);
                g.DrawImage(HeadShot, new Rectangle(0, 0, HeadShot.Width, HeadShot.Height), 0, 0, HeadShot.Width, HeadShot.Height, GraphicsUnit.Pixel, ia);
            }
        }
        // glow: slow breathing while waiting, a flash ring when clicked
        double t = (DateTime.Now - t0).TotalSeconds;
        float breathe = Anim.Reduced ? 0.6f : 0.45f + 0.25f * (float)Math.Sin(t * 1.8);
        float glow = started ? (1 - mv) * (0.9f + 0.6f * (1 - ring)) : breathe + 0.4f * hov;
        for (int i = 4; i >= 1; i--) {
            float rr = r + i * r * 0.45f;
            using (var b = new SolidBrush(Color.FromArgb((int)Math.Min(255, glow * (64 - i * 13)), T.Lamp))) g.FillEllipse(b, lc.X - rr, lc.Y - rr, rr * 2, rr * 2);
        }
        if (started && ring < 1) {
            float rr = r0 + T.D(160) * ring;
            using (var pen = new Pen(Color.FromArgb((int)(200 * (1 - ring)), T.Lamp), T.D(3) * (1 - ring) + 1)) g.DrawEllipse(pen, l0.X - rr, l0.Y - rr, rr * 2, rr * 2);
        }
        using (var b = new SolidBrush(T.Lamp)) g.FillEllipse(b, lc.X - r, lc.Y - r, r * 2, r * 2);
        var f = T.Display((float)Math.Round(size * 4) / 4);
        var sz = g.MeasureString("Lumen", f, PointF.Empty, StringFormat.GenericTypographic);
        using (var b = new SolidBrush(T.Ink)) g.DrawString("Lumen", f, b, tx, lc.Y - sz.Height / 2, StringFormat.GenericTypographic);
        float hint = started ? 1 - Anim.Out(p / 0.2f) : Math.Min(1, (float)t / 0.8f);
        if (hint > 0) {
            var hf = T.Body(10.5f, false); string ht = "Click the light to start";
            var hs = g.MeasureString(ht, hf);
            using (var b = new SolidBrush(Color.FromArgb((int)(255 * hint), T.Mute))) g.DrawString(ht, hf, b, (ClientSize.Width - hs.Width) / 2, lr.Bottom + T.D(28));
        }
    }
    protected override void Dispose(bool d) { if (d) { tm.Dispose(); if (HeadShot != null) HeadShot.Dispose(); } base.Dispose(d); }
}

class RenameForm : Form {
    public TextBox Box;
    public RenameForm(string name) {
        Text = "Rename clip"; FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false; MinimizeBox = false;
        StartPosition = FormStartPosition.CenterParent; ShowInTaskbar = false; AutoScaleMode = AutoScaleMode.None;
        BackColor = T.Table; Font = T.Body(11, false); ForeColor = T.Ink; Icon = T.MakeIcon(32);
        ClientSize = new Size(T.D(440), T.D(150));
        Box = new TextBox { Text = name, MaxLength = 60, BorderStyle = BorderStyle.FixedSingle, Location = new Point(T.D(24), T.D(28)), Width = T.D(392) };
        var ok = new Btn("Rename", true); var cancel = new Btn("Cancel", false);
        ok.Location = new Point(ClientSize.Width - ok.Width - T.D(24), ClientSize.Height - ok.Height - T.D(20));
        cancel.Location = new Point(ok.Left - cancel.Width - T.D(10), ok.Top);
        Action go = () => { if (Box.Text.Trim() != "") { DialogResult = DialogResult.OK; Close(); } };
        ok.Click += (s, e) => go(); cancel.Click += (s, e) => Close();
        Box.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; go(); } else if (e.KeyCode == Keys.Escape) Close(); };
        Shown += (s, e) => { Box.Focus(); Box.SelectAll(); };
        Controls.AddRange(new Control[] { Box, ok, cancel });
    }
}

// ---------- main window ----------
class MainForm : Form {
    [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr h, int id, uint mods, uint vk);
    [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr h, int id);

    Canvas head; Gallery gal; SetupView setup; PlayerView player; DateTime flashAt = DateTime.MinValue; Btn bSave, bSettings, bFolder;
    NotifyIcon tray; ToolStripMenuItem trayPause;
    Recorder rec = new Recorder(); LoopAudio audio = new LoopAudio(false), mic = new LoopAudio(true);
    enum St { Starting, Live, Saving, Paused, Error, Setup }
    St state = St.Starting; string errText = "";
    System.Windows.Forms.Timer pulse; double pulseT;
    bool quitting, startHidden, started, toldTray, keyOk, hideLogo;
    Splash splash; Btn bUpdate;
    Rectangle statusRect;
    Dictionary<string, Clip> known = new Dictionary<string, Clip>();
    Queue<Clip> thumbQ = new Queue<Clip>(); AutoResetEvent thumbEv = new AutoResetEvent(false);

    public MainForm(bool hidden) {
        startHidden = hidden;
        Text = "Lumen"; AutoScaleMode = AutoScaleMode.None; BackColor = T.Table; Icon = T.MakeIcon(32);
        ClientSize = new Size(T.D(1080), T.D(700)); MinimumSize = new Size(T.D(620), T.D(460));
        StartPosition = FormStartPosition.CenterScreen; KeyPreview = true;

        head = new Canvas { Dock = DockStyle.Top, Height = T.D(92), BackColor = T.Table };
        head.Paint += (s, e) => PaintHead(e.Graphics);
        head.MouseMove += (s, e) => head.Cursor = statusRect.Contains(e.Location) && (state == St.Error || state == St.Paused) ? Cursors.Hand : Cursors.Default;
        head.MouseUp += (s, e) => { if (statusRect.Contains(e.Location)) { if (state == St.Error) Begin(); else if (state == St.Paused) Resume(); } };
        bSave = new Btn("Save clip", true); bSave.Click += (s, e) => SaveClip();
        bSettings = new Btn("Settings", false); bSettings.Click += (s, e) => OpenSettings();
        bFolder = new Btn("Open folder", false); bFolder.Click += (s, e) => { try { Process.Start(Cfg.ClipDir); } catch { } };
        bUpdate = new Btn("Update", false) { Visible = false };
        bUpdate.Click += (s, e) => InstallUpdate();
        head.Controls.AddRange(new Control[] { bSave, bSettings, bFolder, bUpdate });
        head.Resize += (s, e) => PlaceButtons();

        gal = new Gallery { Dock = DockStyle.Fill };
        gal.Act += OnAct;
        setup = new SetupView { Dock = DockStyle.Fill, Visible = false };
        setup.Go.Click += (s, e) => Download();
        player = new PlayerView { Dock = DockStyle.Fill, Visible = false };
        player.Act += OnAct;
        player.CardRect = c => gal.ThumbOnScreen(c);
        player.Closed += () => { player.Visible = false; gal.Visible = true; gal.Focus(); gal.Kick(); };
        Controls.Add(gal); Controls.Add(setup); Controls.Add(player); Controls.Add(head);
        gal.BringToFront(); setup.BringToFront(); player.BringToFront();

        pulse = new System.Windows.Forms.Timer { Interval = 33 };
        pulse.Tick += (s, e) => {
            pulseT += 0.12; head.Invalidate(new Rectangle(0, 0, T.D(120), head.Height));
            if (state != St.Saving && Anim.Since(flashAt, 900) >= 1) pulse.Stop();
        };

        var menu = new ContextMenuStrip(); menu.Font = T.Body(10, false);
        menu.Items.Add("Open Lumen", null, (s, e) => ShowMain());
        menu.Items.Add("Save clip", null, (s, e) => SaveClip());
        trayPause = new ToolStripMenuItem("Pause recording", null, (s, e) => { if (state == St.Paused) Resume(); else Pause(); });
        menu.Items.Add(trayPause);
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Quit Lumen", null, (s, e) => { quitting = true; Close(); });
        tray = new NotifyIcon { Icon = T.MakeIcon(32), Text = "Lumen", Visible = true, ContextMenuStrip = menu };
        tray.MouseClick += (s, e) => { if (e.Button == MouseButtons.Left) ShowMain(); };

        var th = new Thread(ThumbWorker); th.IsBackground = true; th.Start();
        rec.Changed += (ok, msg) => { try { BeginInvoke((Action)(() => OnRec(ok, msg))); } catch { } };
        UpdateKeyHint();
        Activated += (s, e) => { if (started) LoadClips(); };
    }

    protected override void SetVisibleCore(bool value) {
        if (!started) {
            started = true;
            if (!IsHandleCreated) CreateHandle();
            Startup();
            if (startHidden) { base.SetVisibleCore(false); return; }
        }
        base.SetVisibleCore(value);
    }

    void Startup() {
        var ev = new EventWaitHandle(false, EventResetMode.AutoReset, "Lumen.Show");
        var t = new Thread(() => { while (true) { ev.WaitOne(); try { BeginInvoke((Action)ShowMain); } catch { } } });
        t.IsBackground = true; t.Start();
        RegisterKey();
        LoadClips();
        if (Cfg.FFmpeg == null) { SetState(St.Setup); setup.Visible = true; gal.Visible = false; }
        else Begin();
        if (!startHidden) ShowSplash();
        Stats.Ping("open");
        new Thread(() => {
            Thread.Sleep(4000);
            if (Updater.Check() == null && Updater.HasUpdate) try { BeginInvoke((Action)(() => { ShowUpdate(); Toast.Show("Update ready", "Lumen " + Updater.Latest + " is out. Click Update in the top bar.", true); })); } catch { }
        }) { IsBackground = true }.Start();
    }

    void ShowSplash() {
        splash = new Splash { Bounds = ClientRectangle, Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right, HeadH = head.Height };
        splash.Clicked += () => {
            hideLogo = true; head.Invalidate(); head.Update();
            var bmp = new Bitmap(Math.Max(1, head.Width), Math.Max(1, head.Height));
            try { head.DrawToBitmap(bmp, new Rectangle(0, 0, head.Width, head.Height)); } catch { }
            splash.HeadShot = bmp;
        };
        splash.Done += () => {
            Controls.Remove(splash); splash.Dispose(); splash = null;
            hideLogo = false; head.Invalidate();
            if (gal.Visible) { gal.Focus(); gal.Intro(); }
        };
        Controls.Add(splash); splash.BringToFront(); splash.Focus();
    }
    void ShowUpdate() {
        bUpdate.Text = "Update to " + Updater.Latest; bUpdate.Fit(); bUpdate.Visible = Updater.HasUpdate; PlaceButtons(); head.Invalidate();
    }
    void InstallUpdate() {
        if (!Updater.HasUpdate) return;
        bUpdate.Enabled = false;
        Toast.Show("Updating Lumen", "Downloading " + Updater.Latest + ". Lumen opens again by itself.", true);
        new Thread(() => {
            string err = Updater.Install();
            BeginInvoke((Action)(() => {
                if (err != null) { bUpdate.Enabled = true; Toast.Show("Update failed", err, false); return; }
                quitting = true; Close();
            }));
        }) { IsBackground = true }.Start();
    }
    void ShowMain() {
        bool wasHidden = !Visible;
        Show(); if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
        Activate(); LoadClips();
        if (wasHidden && gal.Visible) gal.Intro();
    }

    // ----- recording -----
    void Begin() {
        SetState(St.Starting);
        new Thread(() => {
            Recorder.KillStale();
            string enc = Cfg.Get("encoder", "");
            string ff = Cfg.FFmpeg;
            if (enc == "" || Cfg.Get("encoderFor", "") != ff + Cfg.Screen) {
                enc = Recorder.Probe();
                if (enc != null) { Cfg.Set("encoder", enc); Cfg.Set("encoderFor", ff + Cfg.Screen); }
            }
            BeginInvoke((Action)(() => {
                if (enc == null) { errText = "Screen capture did not start. Update your graphics driver and try again."; SetState(St.Error); return; }
                rec.Encoder = enc; rec.Start(); audio.Start(); if (Cfg.Get("mic", "1") == "1") mic.Start();
            }));
        }) { IsBackground = true }.Start();
    }
    void OnRec(bool ok, string msg) {
        if (state == St.Paused || quitting) return;
        if (ok) { if (state != St.Saving) SetState(St.Live); }
        else {
            errText = string.IsNullOrEmpty(msg) ? "Recording stopped." : "Recording stopped: " + msg;
            Cfg.Set("encoder", "");
            SetState(St.Error);
        }
    }
    void Pause() { rec.Stop(); SetState(St.Paused); }
    void Resume() { if (rec.Encoder == null) Begin(); else { SetState(St.Starting); rec.Start(); } }

    void SetState(St s) {
        state = s;
        if (s == St.Saving) { pulseT = 0; pulse.Start(); }
        trayPause.Text = s == St.Paused ? "Resume recording" : "Pause recording";
        bSave.Enabled = s == St.Live;
        string tt = "Lumen: " + StatusText().Split('.')[0]; tray.Text = tt.Length > 63 ? tt.Substring(0, 63) : tt;
        head.Invalidate();
    }
    string StatusText() {
        switch (state) {
            case St.Live: return "Recording. Press " + Cfg.Key + " to keep the last " + Cfg.LenText(Cfg.Length) + ".";
            case St.Saving: return "Saving clip…";
            case St.Paused: return "Paused. Click to start again.";
            case St.Error: return errText + " Click to try again.";
            case St.Setup: return "Setup needed before Lumen can record.";
            default: return "Starting…";
        }
    }

    void SaveClip() {
        if (state != St.Live) {
            if (state == St.Saving) return;
            Toast.Show("Not recording", state == St.Paused ? "Recording is paused. Resume it first." : "Lumen is not recording right now.", false);
            return;
        }
        var t = DateTime.Now; string title = Clipper.GameTitle();
        SetState(St.Saving);
        new Thread(() => {
            string err; string file = null;
            try { file = Clipper.Save(rec, audio, mic, t, title, out err); } catch (Exception ex) { err = ex.Message; }
            BeginInvoke((Action)(() => {
                if (state == St.Saving) SetState(rec.Running ? St.Live : St.Error);
                if (file != null) {
                    Toast.Show("Clip saved", title + ", " + Cfg.LenText(Cfg.Length), true);
                    flashAt = DateTime.Now; pulse.Start(); Stats.Ping("clip"); Chime.Play();
                    LoadClips(); Clip nc; if (known.TryGetValue(file, out nc)) gal.Develop(nc);
                }
                else Toast.Show("Clip not saved", err, false);
            }));
        }) { IsBackground = true }.Start();
    }

    // ----- hotkey -----
    void RegisterKey() {
        UnregisterHotKey(Handle, 1);
        uint mods = 0x4000, vk = 0;
        foreach (var part in Cfg.Key.Split('+')) {
            var p = part.Trim();
            if (p == "Alt") mods |= 1; else if (p == "Ctrl") mods |= 2; else if (p == "Shift") mods |= 4;
            else { Keys k; if (Enum.TryParse(p, out k)) vk = (uint)k; }
        }
        keyOk = vk != 0 && RegisterHotKey(Handle, 1, mods, vk);
        if (!keyOk) Toast.Show(Cfg.Key + " is taken", "Another app uses this key. Pick a different one in Settings.", false);
    }
    void UpdateKeyHint() { bSave.Hint = Cfg.Key; bSave.Fit(); PlaceButtons(); gal.KeyName = Cfg.Key; gal.LengthSec = Cfg.Length; }
    protected override void WndProc(ref Message m) {
        if (m.Msg == 0x0312 && m.WParam.ToInt32() == 1) SaveClip();
        base.WndProc(ref m);
    }
    protected override void OnKeyDown(KeyEventArgs e) {
        if (e.KeyCode == Keys.F5) LoadClips();
        base.OnKeyDown(e);
    }

    // ----- header -----
    void PlaceButtons() {
        int x = head.ClientSize.Width - T.D(32), y = (head.Height - bSave.Height) / 2;
        foreach (var b in new[] { bSave, bSettings, bFolder, bUpdate }) { if (!b.Visible && b == bUpdate) continue; x -= b.Width; b.Location = new Point(x, y); x -= T.D(10); }
    }
    void PaintHead(Graphics g) {
        T.Hq(g);
        int x = T.D(32), cy = head.Height / 2;
        if (hideLogo) { PaintStatus(g, T.D(32) + T.D(30) + TextRenderer.MeasureText("Lumen", T.Display(21)).Width + T.D(22), cy); return; }
        // The lamp is the logo and the record light: lit while Lumen keeps your clips.
        bool lit = state == St.Live || state == St.Saving;
        Color lamp = state == St.Error ? T.Stop : lit ? T.Lamp : T.Soft;
        float r = T.D(8), lx = x + r;
        if (lit) {
            double k = state == St.Saving ? 0.5 + 0.5 * Math.Sin(pulseT) : 0.6;
            for (int i = 3; i >= 1; i--) {
                float rr = r + i * T.D(4);
                using (var b = new SolidBrush(Color.FromArgb((int)(k * (60 - i * 15)), T.Lamp))) g.FillEllipse(b, lx - rr, cy - rr, rr * 2, rr * 2);
            }
        }
        float fl = Anim.Since(flashAt, 900);
        if (fl < 1) {
            float e = Anim.Out(fl), rr = r + T.D(40) * e;
            using (var pen = new Pen(Color.FromArgb((int)(220 * (1 - e)), T.Lamp), T.D(2.5f) * (1 - e) + 1)) g.DrawEllipse(pen, lx - rr, cy - rr, rr * 2, rr * 2);
            using (var b = new SolidBrush(Color.FromArgb((int)(120 * (1 - e)), T.Lamp))) g.FillEllipse(b, lx - r * 2.2f, cy - r * 2.2f, r * 4.4f, r * 4.4f);
        }
        using (var b = new SolidBrush(lamp)) g.FillEllipse(b, lx - r, cy - r, r * 2, r * 2);
        var f = T.Display(21);
        int wx = x + T.D(30), ww = TextRenderer.MeasureText("Lumen", f).Width;
        T.Text(g, "Lumen", f, T.Ink, new Rectangle(wx, 0, ww + 4, head.Height), TextFormatFlags.VerticalCenter);
        PaintStatus(g, wx + ww + T.D(22), cy);
    }
    void PaintStatus(Graphics g, int sx, int cy) {
        var left = bUpdate.Visible ? bUpdate : bFolder;
        int maxW = Math.Max(0, left.Left - sx - T.D(16));
        statusRect = new Rectangle(sx, cy - T.D(12), maxW, T.D(24));
        T.Text(g, StatusText(), T.Body(10, false), state == St.Error ? T.Stop : T.Mute, statusRect, TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
    }

    // ----- clips -----
    static readonly Regex NameRx = new Regex(@"^(.*) \d{4}-\d{2}-\d{2} \d{2}\.\d{2}\.\d{2}$");
    void LoadClips() {
        string[] files;
        try { files = Directory.GetFiles(Cfg.ClipDir, "*.mp4"); } catch { files = new string[0]; }
        var list = new List<Clip>();
        foreach (var f in files) {
            Clip c;
            if (!known.TryGetValue(f, out c)) {
                string n = Path.GetFileNameWithoutExtension(f); var m = NameRx.Match(n);
                c = new Clip { Path = f, Title = m.Success ? m.Groups[1].Value : n, When = File.GetLastWriteTime(f) };
                known[f] = c;
            }
            if (c.Thumb == null && !c.Queued) {
                string k = Thumbs.Key(f);
                if (File.Exists(k + ".jpg")) LoadThumb(c, k);
                else { c.Queued = true; lock (thumbQ) thumbQ.Enqueue(c); thumbEv.Set(); }
            }
            list.Add(c);
        }
        gal.Clips = list.OrderByDescending(c => c.When).ToList();
        gal.Relayout();
    }
    static void LoadThumb(Clip c, string k) {
        try {
            using (var fs = File.OpenRead(k + ".jpg")) using (var img = Image.FromStream(fs)) c.Thumb = new Bitmap(img);
            if (File.Exists(k + ".txt")) {
                var parts = File.ReadAllText(k + ".txt").Split('\n'); double d;
                if (double.TryParse(parts[0].Trim(), NumberStyles.Float, Cfg.CI, out d)) c.Dur = d;
                c.HasMic = parts.Length > 1 && parts[1].Trim() == "1";
                c.MicOn = parts.Length < 3 || parts[2].Trim() == "1";
            }
        } catch { }
    }
    void ThumbWorker() {
        while (true) {
            thumbEv.WaitOne();
            while (true) {
                Clip c = null;
                lock (thumbQ) if (thumbQ.Count > 0) c = thumbQ.Dequeue();
                if (c == null) break;
                if (Cfg.FFmpeg == null) { c.Queued = false; continue; }
                try { Thumbs.Make(c.Path, -1); LoadThumb(c, Thumbs.Key(c.Path)); } catch { }
                c.Queued = false;
                try { BeginInvoke((Action)(() => gal.Invalidate())); } catch { }
            }
        }
    }

    void OnAct(string what, Clip c) {
        if (!File.Exists(c.Path)) { LoadClips(); return; }
        switch (what) {
            case "Play": OpenPlayer(c); break;
            case "Show in folder": Process.Start("explorer.exe", "/select,\"" + c.Path + "\""); break;
            case "Copy file": CopyFiles(c.Path); Toast.Show("Copied", "Paste it anywhere to send the full-size clip.", true); break;
            case "Delete":
                if (player.Visible && player.Clip == c) player.CloseNow();
                try {
                    Microsoft.VisualBasic.FileIO.FileSystem.DeleteFile(c.Path, Microsoft.VisualBasic.FileIO.UIOption.OnlyErrorDialogs, Microsoft.VisualBasic.FileIO.RecycleOption.SendToRecycleBin);
                    known.Remove(c.Path); if (c.Thumb != null) c.Thumb.Dispose();
                    Toast.Show("Deleted", "The clip is in the Recycle Bin if you need it back.", true);
                } catch (Exception ex) { Toast.Show("Not deleted", ex.Message, false); }
                LoadClips(); break;
            case "Share": Share(c); break;
            case "Rename": RenameClip(c); break;
            case "Mic": ToggleMic(c); break;
        }
    }
    void OpenPlayer(Clip c) {
        if (player.Visible || gal.Width < 10) return;
        var old = player.Backdrop;
        var bmp = new Bitmap(gal.Width, gal.Height);
        try { gal.DrawToBitmap(bmp, new Rectangle(0, 0, gal.Width, gal.Height)); } catch { }
        player.Backdrop = bmp; if (old != null) old.Dispose();
        player.Visible = true; gal.Visible = false;
        player.Open(c);
    }
    protected override bool ProcessCmdKey(ref Message msg, Keys k) {
        if (splash != null) return base.ProcessCmdKey(ref msg, k);
        if (player.Visible && !player.Busy) {
            switch (k) {
                case Keys.Space: player.Toggle(); return true;
                case Keys.Left: player.Skip(-5); return true;
                case Keys.Right: player.Skip(5); return true;
                case Keys.M: player.ToggleMute(); return true;
                case Keys.Escape: player.Close(); return true;
            }
        }
        return base.ProcessCmdKey(ref msg, k);
    }
    bool openHere(Clip c) { return player.Visible && player.Clip == c; }
    void RenameClip(Clip c) {
        string nt;
        using (var f = new RenameForm(c.Title)) { if (f.ShowDialog(this) != DialogResult.OK) return; nt = f.Box.Text.Trim(); }
        if (nt == c.Title) return;
        bool open = openHere(c); if (open) player.Release();
        try {
            string np = Clipper.Rename(c, nt);
            known.Remove(c.Path); c.Path = np; c.Title = nt; known[np] = c;
            Toast.Show("Renamed", nt, true);
        } catch (Exception ex) { Toast.Show("Not renamed", ex.Message, false); }
        if (open) player.Reopen();
        LoadClips();
    }
    void ToggleMic(Clip c) {
        bool open = openHere(c); if (open) player.Release();
        string err; bool ok = false;
        try { ok = Clipper.SwapMic(c, out err); } catch (Exception ex) { err = ex.Message; }
        if (ok) {
            LoadThumbFor(c);
            if (c.MicOn) Toast.Show("Mic on", "Your voice is back in the clip.", true);
            else Toast.Show("Mic off", "Only game sound plays now. Turn it back on any time.", true);
        } else Toast.Show("Mic not changed", err, false);
        if (open) player.Reopen();
        LoadClips();
    }
    void LoadThumbFor(Clip c) { if (c.Thumb != null) { c.Thumb.Dispose(); c.Thumb = null; } LoadThumb(c, Thumbs.Key(c.Path)); }
    void CopyFiles(string path) { var sc = new StringCollection(); sc.Add(path); Clipboard.SetFileDropList(sc); }
    void Share(Clip c) {
        bool big = new FileInfo(c.Path).Length > 9500000;
        if (big) Toast.Show("Making it ready to share", "Shrinking the clip to under 10 MB for Discord.", true);
        string enc = rec.Encoder;
        new Thread(() => {
            string err = null, file = null;
            try { file = Clipper.ShareFile(c.Path, c.Dur, enc, out err); } catch (Exception ex) { err = ex.Message; }
            BeginInvoke((Action)(() => {
                if (file == null) { Toast.Show("Not ready to share", err, false); return; }
                CopyFiles(file);
                Toast.Show("Ready to share", "Copied. Paste it in Discord, WhatsApp or anywhere.", true);
            }));
        }) { IsBackground = true }.Start();
    }

    // ----- settings -----
    void OpenSettings() {
        string before = Cfg.Length + "|" + Cfg.Fps + "|" + Cfg.Quality + "|" + Cfg.Screen;
        string keyBefore = Cfg.Key, dirBefore = Cfg.ClipDir;
        using (var f = new SettingsForm()) if (f.ShowDialog(this) != DialogResult.OK) return;
        ShowUpdate();
        if (Cfg.Key != keyBefore) RegisterKey();
        if (Cfg.Get("mic", "1") == "1") { if (rec.Encoder != null) mic.Start(); } else mic.Stop();
        UpdateKeyHint();
        if (Cfg.ClipDir != dirBefore) { known.Clear(); LoadClips(); }
        string after = Cfg.Length + "|" + Cfg.Fps + "|" + Cfg.Quality + "|" + Cfg.Screen;
        if (after != before && state != St.Setup && state != St.Paused) Begin();
        gal.Relayout(); head.Invalidate();
    }

    // ----- ffmpeg download -----
    void Download() {
        setup.Go.Enabled = false; setup.Error = null; setup.Progress = 0; setup.Invalidate();
        new Thread(() => {
            string dir = Path.Combine(Cfg.Local, "ffmpeg"), zip = Path.Combine(Cfg.Local, "ffmpeg.zip"), err = null;
            Directory.CreateDirectory(dir);
            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
            foreach (var url in new[] {
                "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip",
                "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip" }) {
                try {
                    using (var wc = new WebClient()) {
                        var done = new ManualResetEvent(false); Exception dlErr = null;
                        wc.DownloadProgressChanged += (s, e) => {
                            if (e.ProgressPercentage != setup.Progress) { setup.Progress = e.ProgressPercentage; try { BeginInvoke((Action)(() => setup.Invalidate())); } catch { } }
                        };
                        wc.DownloadFileCompleted += (s, e) => { dlErr = e.Error; done.Set(); };
                        wc.DownloadFileAsync(new Uri(url), zip);
                        done.WaitOne();
                        if (dlErr != null) throw dlErr;
                    }
                    setup.Progress = 100; BeginInvoke((Action)(() => setup.Invalidate()));
                    using (var z = ZipFile.OpenRead(zip)) {
                        var en = z.Entries.FirstOrDefault(x => x.FullName.EndsWith("bin/ffmpeg.exe", StringComparison.OrdinalIgnoreCase));
                        if (en == null) throw new Exception("ffmpeg.exe was not in the download.");
                        en.ExtractToFile(Path.Combine(dir, "ffmpeg.exe"), true);
                    }
                    try { File.Delete(zip); } catch { }
                    err = null; break;
                } catch (Exception ex) { err = ex.Message; }
            }
            BeginInvoke((Action)(() => {
                setup.Progress = -1; setup.Go.Enabled = true;
                if (err != null || Cfg.FFmpeg == null) { setup.Error = err ?? "ffmpeg.exe not found."; setup.Invalidate(); return; }
                setup.Visible = false; gal.Visible = true; LoadClips(); Begin();
            }));
        }) { IsBackground = true }.Start();
    }

    // ----- closing -----
    protected override void OnFormClosing(FormClosingEventArgs e) {
        if (e.CloseReason == CloseReason.UserClosing && !quitting) {
            e.Cancel = true;
            if (player.Visible) player.CloseNow();
            Hide();
            if (!toldTray) {
                toldTray = true;
                tray.ShowBalloonTip(3000, "Lumen is still recording", "Press " + Cfg.Key + " to save a clip. Right-click the tray icon to quit.", ToolTipIcon.None);
            }
            return;
        }
        player.Release(); rec.Stop(); audio.Stop(); mic.Stop();
        try { UnregisterHotKey(Handle, 1); } catch { }
        tray.Visible = false;
        base.OnFormClosing(e);
    }
}
